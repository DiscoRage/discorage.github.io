"""Scraping: year and genre where the library has none, and the largest artwork found.

Names are never changed. An album is looked up by its album artist and title; artists only if they
are credited on an album, so featured artists on a song are never scraped. Artwork is replaced
whenever a larger image is found (album covers and artist thumbs must be square), the current one
included in the comparison, so a big folder.jpg stays.

Runs in the background (DialogProgressBG). Progress is kept in addon_data/state.json: albums done,
albums skipped by hand, and albums not found, which wait for a search by hand or a skip. "New
albums" leaves out the done and the skipped; "All albums" only the skipped.
"""
import json
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import library
import sources

STATE = 'special://profile/addon_data/script.az2music.scraper/state.json'
HOME = xbmcgui.Window(10000)
RUNNING, STOP = 'az2scraper.running', 'az2scraper.stop'
FIRST = {'TheAudioDB': 0, 'MusicBrainz': 1}   # whose year and genre win (Apple's are never used)


def load():
    try:
        with xbmcvfs.File(STATE) as f:
            state = json.loads(f.read() or '{}')
    except (ValueError, OSError):
        state = {}
    return {'done': set(state.get('done') or []), 'skipped': set(state.get('skipped') or []),
            'unmatched': state.get('unmatched') or {}}


def save(state):
    xbmcvfs.mkdirs('special://profile/addon_data/script.az2music.scraper/')
    with xbmcvfs.File(STATE, 'w') as f:
        f.write(json.dumps({'done': sorted(state['done']), 'skipped': sorted(state['skipped']),
                            'unmatched': state['unmatched']}))


def album_key(artist, title):
    return f'{sources.norm(artist)}|{sources.norm(title)}'


def api_key():
    return xbmcaddon.Addon().getSetting('fanarttv_key').strip()


def bigger(new, current):
    return new[0] * new[1] > current[0] * current[1]


def album_fields(album, candidates):
    """What to change on an album, from its candidates."""
    fields = {}
    ranked = sorted(candidates, key=lambda c: FIRST.get(c['source'], 9))
    if not album.get('year'):
        year = next((c['year'] for c in ranked if c['year'][:4].isdigit()), '')
        if year:
            fields['year'] = int(year[:4])
    if not album.get('genre'):
        genre = next((c['genre'] for c in ranked if c['genre']), '')
        if genre:
            fields['genre'] = [genre]
    # The release group (every edition) if missing; never a release ID, which splits albums
    if not album.get('musicbrainzreleasegroupid'):
        group = next((c['releasegroup'] for c in ranked if c['releasegroup']), '')
        if group:
            fields['musicbrainzreleasegroupid'] = group
    url, size = sources.largest([u for c in candidates for u in c['covers']])
    current = (album.get('art') or {}).get('thumb', '')
    if url and bigger(size, sources.image_size(current)):
        fields['art'] = {'thumb': url}
    return fields


def artist_fields(artist, key):
    """What to change on an artist, or None when no source knows them."""
    found = sources.tadb_artist(artist['artist']) or {}
    mbid = next(iter(artist.get('musicbrainzartistid') or []), '') or found.get('mbid', '')
    fanart = sources.fanart_artist(mbid, key)
    if not found and not fanart['thumb'] and not fanart['fanart']:
        return None
    fields, art = {}, {}
    if not artist.get('genre') and found.get('genre'):
        fields['genre'] = [found['genre']]
    for kind, need_square in (('thumb', True), ('fanart', False)):
        url, size = sources.largest(found.get(kind, []) + fanart[kind], need_square)
        if url and bigger(size, sources.image_size((artist.get('art') or {}).get(kind, ''))):
            art[kind] = url
    if art:
        fields['art'] = art
    return fields


def run_albums(everything):
    state = load()
    key = api_key()
    counts = library.track_counts()
    todo = [a for a in library.albums()
            if album_key(a['displayartist'], a['title']) not in state['skipped']
            and (everything or album_key(a['displayartist'], a['title']) not in state['done'])]
    if not todo:
        xbmcgui.Dialog().ok('Minimalist Scraper', 'Every album has been scraped already.')
        return
    minutes = max(1, round(len(todo) * 4 / 60))
    if not xbmcgui.Dialog().yesno('Minimalist Scraper', f'{len(todo)} albums to look up, roughly {minutes} minutes.\n'
                                  'It runs in the background; open the add-on again to stop it.'):
        return
    updated, unmatched_before = 0, len(state['unmatched'])
    with Run('Scraping albums') as run:
        for n, album in enumerate(todo):
            if run.stopped():
                break
            artist, title = album['displayartist'], album['title']
            run.update(n, len(todo), f'{artist} - {title}')
            k = album_key(artist, title)
            candidates = sources.album_candidates(artist, title, counts.get(album['albumid'], 0), key)
            if not candidates:
                state['unmatched'][k] = [album['albumid'], artist, title]
            else:
                state['unmatched'].pop(k, None)
                fields = album_fields(album, candidates)
                if fields and library.set_album(album['albumid'], **fields):
                    updated += 1
                    library.log(f'{artist} - {title}: {sorted(fields)}')
                state['done'].add(k)
            if n % 10 == 0:
                save(state)
        save(state)
    new = len(state['unmatched']) - unmatched_before
    xbmcgui.Dialog().notification('Minimalist Scraper', f'Albums: {updated} updated, {new} not found', time=6000)
    if state['unmatched'] and xbmcgui.Dialog().yesno(
            'Minimalist Scraper', f'{len(state["unmatched"])} albums weren\'t found online. Go through them now?'):
        review()


def run_artists():
    key = api_key()
    artists = [a for a in library.album_artists() if sources.norm(a['artist']) not in ('various artists', '')]
    if not artists:
        return
    minutes = max(1, round(len(artists) * 3 / 60))
    if not xbmcgui.Dialog().yesno('Minimalist Scraper', f'{len(artists)} album artists to look up, roughly {minutes} '
                                  'minutes.\nIt runs in the background; open the add-on again to stop it.'):
        return
    updated = missing = 0
    with Run('Scraping album artists') as run:
        for n, artist in enumerate(artists):
            if run.stopped():
                break
            run.update(n, len(artists), artist['artist'])
            fields = artist_fields(artist, key)
            if fields is None:
                missing += 1
            elif fields and library.set_artist(artist['artistid'], **fields):
                updated += 1
                library.log(f'{artist["artist"]}: {sorted(fields)}')
    xbmcgui.Dialog().notification('Minimalist Scraper', f'Artists: {updated} updated, {missing} not found', time=6000)


def review():
    """Albums not found: search again (a typo in the tags, say) or skip, keeping them as tagged."""
    dialog = xbmcgui.Dialog()
    while True:
        state = load()
        waiting = sorted(state['unmatched'].items(), key=lambda kv: (kv[1][1].lower(), kv[1][2].lower()))
        if not waiting:
            dialog.ok('Minimalist Scraper', 'No albums are waiting.')
            return
        pick = dialog.select(f'Albums not found ({len(waiting)})', [f'{a} - {t}' for _, (_, a, t) in waiting])
        if pick < 0:
            return
        k, (albumid, artist, title) = waiting[pick]
        action = dialog.select(f'{artist} - {title}', ['Search again', 'Skip: keep it as tagged'])
        if action == 1:
            state['unmatched'].pop(k, None)
            state['skipped'].add(k)
            save(state)
        elif action == 0 and search_again(albumid, artist, title):
            state['unmatched'].pop(k, None)
            state['done'].add(k)
            save(state)


def search_again(albumid, artist, title):
    dialog = xbmcgui.Dialog()
    artist_term = dialog.input('Search for: artist', artist)
    title_term = dialog.input('Search for: album', title)
    if not (artist_term or title_term):
        return False
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        found = sources.search_albums(artist_term, title_term)
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    if not found:
        dialog.ok('Minimalist Scraper', f'Nothing found on TheAudioDB or MusicBrainz for artist "{artist_term}", '
                  f'album "{title_term}".')
        return False
    labels = [f'{c["source"]}: {c["artist"]} - {c["title"]}' + (f' ({c["year"]})' if c['year'] else '') for c in found]
    pick = dialog.select('Which is it?', labels)
    if pick < 0:
        return False
    pick = found[pick]
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        chosen = ([pick] + sources.apple_covers(pick['artist'], pick['title'], 0)
                  + sources.fanart_candidates([pick], pick['artist'], pick['title'], api_key()))
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    album = (library.rpc('AudioLibrary.GetAlbumDetails', albumid=albumid, properties=['year', 'genre', 'art', 'musicbrainzreleasegroupid']) or {}).get('albumdetails')
    if not album:
        return False
    fields = album_fields(album, chosen)
    if fields:
        library.set_album(albumid, **fields)
    names = {'art': 'cover', 'year': 'year', 'genre': 'genre'}      # the release group goes unmentioned
    changed = ', '.join(names[f] for f in sorted(fields) if f in names)
    dialog.notification('Minimalist Scraper', f'{title}: ' + (f'{changed} updated' if changed else
                                                             'already has its year, genre and the largest cover'))
    return True


class Run:
    """A background progress bar that a second launch of the add-on can stop."""

    def __init__(self, heading):
        self.heading = heading
        self.bar = xbmcgui.DialogProgressBG()
        self.monitor = xbmc.Monitor()

    def __enter__(self):
        HOME.setProperty(RUNNING, self.heading)
        HOME.clearProperty(STOP)
        self.bar.create('Minimalist Scraper', self.heading)
        return self

    def __exit__(self, *exc):
        self.bar.close()
        HOME.clearProperty(RUNNING)
        HOME.clearProperty(STOP)

    def update(self, n, total, message):
        self.bar.update(int(n * 100 / max(total, 1)), 'Minimalist Scraper', f'{self.heading}: {message}')

    def stopped(self):
        return self.monitor.abortRequested() or bool(HOME.getProperty(STOP))


def running():
    return HOME.getProperty(RUNNING)


def stop():
    HOME.setProperty(STOP, '1')
    time.sleep(0.1)
