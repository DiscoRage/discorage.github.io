"""Minimalist (artists): Kodi's scraper protocol, run by script.az2music.scraper's kodi_scraper.py."""
import sys

import xbmcaddon
import xbmcvfs

sys.path.insert(0, xbmcvfs.translatePath(xbmcaddon.Addon('script.az2music.scraper').getAddonInfo('path')))
import kodi_scraper  # noqa: E402

kodi_scraper.run('artists')
