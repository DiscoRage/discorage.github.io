"""Minimalist Library Cleaner: opened from Programs, it runs the one-time clean (clean.py)."""
import clean

clean.run()
