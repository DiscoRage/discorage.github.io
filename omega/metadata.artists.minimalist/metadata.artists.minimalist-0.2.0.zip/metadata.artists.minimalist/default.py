"""Minimalist Artist Scraper: Kodi runs this for each artist it scrapes (see kodi_scraper.py)."""
import kodi_scraper

kodi_scraper.run('artists')
