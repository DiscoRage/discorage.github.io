"""Artist Wall columns for skin.az2music.

The skin's wall is one horizontal list in which every item is a column of ROWS artists, so the
whole wall pans together under a fixed highlight. Artists fill each column top to bottom, then
the next column, so the wall reads alphabetically from left to right.

Called by the skin as plugin://script.az2music.wall/?rows=5&path=<music library folder>
(path last and unparsed, since library paths can carry their own query string).

Each column item has properties name<r>, thumb<r>, fanart<r>, genre<r>, letter<r> and path<r>
for rows r = 0..ROWS-1, plus index (0-based column), count (artists in the column) and last
(set on the final column). Window(Home).Property(az2_wall_letters) lists the letters present.
"""
import json
import math
import re
import sys
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

ADDON = 'script.az2music.wall'


def rpc(method, **params):
    result = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    if 'error' in result:
        xbmc.log(f'[{ADDON}] {method}: {result["error"]}', xbmc.LOGWARNING)
        return {}
    return result.get('result', {})


def letter(name, ignore_the):
    if ignore_the and name.lower().startswith('the '):
        name = name[4:]
    first = name[:1].upper()
    return first if 'A' <= first <= 'Z' else '#'


def artists(path):
    ignore_the = rpc('Settings.GetSettingValue', setting='filelists.ignorethewhensorting').get('value', True)
    items = rpc('Files.GetDirectory', directory=path, media='music', properties=['art', 'genre'],
                sort={'method': 'label', 'order': 'ascending', 'ignorearticle': bool(ignore_the)}).get('files') or []
    for item in items:
        if item.get('filetype') != 'directory' or re.search(r'/-1/', item.get('file', '')):
            continue
        art = item.get('art') or {}
        yield {'name': item.get('label', ''), 'thumb': art.get('thumb', ''), 'fanart': art.get('fanart', ''),
               'genre': ' • '.join(item.get('genre') or []), 'letter': letter(item.get('label', ''), ignore_the),
               'path': item.get('file', '')}


def main():
    handle = int(sys.argv[1])
    query, _, path = sys.argv[2].lstrip('?').partition('path=')
    rows = max(1, int(dict(urllib.parse.parse_qsl(query)).get('rows', 5)))
    found = list(artists(path)) if path else []

    columns = []
    for c in range(math.ceil(len(found) / rows)):
        cells = found[c * rows:(c + 1) * rows]
        props = {'index': str(c), 'count': str(len(cells))}
        for r, artist in enumerate(cells):
            props.update({f'{key}{r}': value for key, value in artist.items()})
        item = xbmcgui.ListItem(label=cells[0]['name'], offscreen=True)
        item.setProperties(props)
        columns.append((f'plugin://{ADDON}/?column={c}', item, False))
    if columns:
        columns[-1][1].setProperty('last', '1')

    letters = {a['letter'] for a in found}
    xbmcgui.Window(10000).setProperty('az2_wall_letters', ''.join(l for l in '#ABCDEFGHIJKLMNOPQRSTUVWXYZ' if l in letters))
    xbmcplugin.addDirectoryItems(handle, columns, len(columns))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


main()
