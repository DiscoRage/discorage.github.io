"""Minimalist Library Cleaner, a one-time clean: biographies, album reviews, moods, styles,
themes, instruments and MusicBrainz release IDs out of the music library.

Release IDs matter most: an album whose rows carry different ones is split into several. Clearing
them doesn't join albums that are split already (they're listed at the end); and Kodi's own
scrapers put all of this back, so the clean offers to make the Minimalist Album and Artist
Scrapers Kodi's (or, without them, to switch "Fetch additional information during scan" off).
Artist MusicBrainz IDs and release groups stay: they find artwork. The music database is copied to
addon_data/backups first. Everything is written through JSON-RPC.
"""
import re
import time
import unicodedata

import xbmc
import xbmcgui
import xbmcvfs

import library

BACKUPS = 'special://profile/addon_data/script.az2music.scraper/backups/'
SCRAPERS = {'musiclibrary.albumsscraper': 'metadata.album.minimalist',
            'musiclibrary.artistsscraper': 'metadata.artists.minimalist'}


def norm(text):
    """A name compared without case, accents, punctuation or a leading "The"."""
    text = unicodedata.normalize('NFKD', text or '').encode('ascii', 'ignore').decode().lower()
    text = re.sub(r'\s*&\s*', ' and ', text)
    return re.sub(r'^the ', '', re.sub(r'[^a-z0-9]+', ' ', text).strip())


def album_dirty(album):
    return bool(album.get('description') or album.get('mood') or album.get('style') or album.get('theme')
                or album.get('musicbrainzalbumid'))


def artist_dirty(artist):
    return bool(artist.get('description') or artist.get('mood') or artist.get('style') or artist.get('instrument'))


def backup():
    """Copy the newest MyMusic database; the file name, or '' if it couldn't be copied."""
    _, files = xbmcvfs.listdir('special://database/')
    dbs = sorted((f for f in files if f.startswith('MyMusic') and f.endswith('.db')),
                 key=lambda f: int(''.join(c for c in f if c.isdigit()) or 0))
    if not dbs:
        return ''
    xbmcvfs.mkdirs(BACKUPS)
    target = f'{BACKUPS}{dbs[-1][:-3]}-{time.strftime("%Y%m%d-%H%M%S")}.db'
    return target if xbmcvfs.copy(f'special://database/{dbs[-1]}', target) else ''


def run():
    dialog = xbmcgui.Dialog()
    albums, artists = library.albums(), library.all_artists()
    dirty_albums = [a for a in albums if album_dirty(a)]
    dirty_artists = [a for a in artists if artist_dirty(a)]
    count = lambda rows, field: sum(1 for r in rows if r.get(field))
    if dirty_albums or dirty_artists:
        summary = (f'Albums: {count(albums, "musicbrainzalbumid")} release IDs, {count(albums, "description")} reviews, '
                   f'{sum(1 for a in albums if a.get("mood") or a.get("style") or a.get("theme"))} with moods, styles or themes.\n'
                   f'Artists: {count(artists, "description")} biographies, '
                   f'{sum(1 for a in artists if a.get("mood") or a.get("style") or a.get("instrument"))} with moods, styles or instruments.\n\n'
                   'Clear them all? The music database is backed up first.')
        if not dialog.yesno('Clean library', summary):
            return
    fetching = library.setting('musiclibrary.downloadinfo')
    others = {k: v for k, v in SCRAPERS.items() if library.setting(k) != v}
    if all(xbmc.getCondVisibility(f'System.AddonIsEnabled({v})') for v in SCRAPERS.values()):
        if (others or not fetching) and dialog.yesno(
                'Clean library', 'Use the Minimalist Album and Artist Scrapers when Kodi scans, so new music '
                'gets its year, genre and artwork without reviews, biographies or release IDs?'):
            for setting, scraper in SCRAPERS.items():
                library.set_setting(setting, scraper)
            library.set_setting('musiclibrary.downloadinfo', True)
    elif fetching and dialog.yesno(
            'Clean library', 'Kodi\'s "Fetch additional information during scan" is on: its album and artist '
            'scrapers add reviews, biographies and release IDs back.\n\nTurn it off? (Or install the Minimalist '
            'Album and Artist Scrapers and clean again to use them instead.)'):
        library.set_setting('musiclibrary.downloadinfo', False)
    if not (dirty_albums or dirty_artists):
        dialog.ok('Clean library', 'Nothing to clean: no biographies, reviews, moods, styles or release IDs.')
        return
    saved = backup()
    if not saved and not dialog.yesno('Clean library', 'The music database couldn\'t be backed up. Clean anyway?'):
        return
    bar = xbmcgui.DialogProgress()
    bar.create('Clean library')
    failed = 0
    total = len(dirty_albums) + len(dirty_artists)
    try:
        for n, album in enumerate(dirty_albums):
            if bar.iscanceled():
                break
            bar.update(int(n * 100 / total), f'{album["displayartist"]} - {album["title"]}')
            failed += not library.set_album(album['albumid'], description='', mood=[], style=[], theme=[],
                                            musicbrainzalbumid='')
        for n, artist in enumerate(dirty_artists, len(dirty_albums)):
            if bar.iscanceled():
                break
            bar.update(int(n * 100 / total), artist['artist'])
            failed += not library.set_artist(artist['artistid'], description='', mood=[], style=[], instrument=[])
    finally:
        bar.close()
    split = {}
    for album in library.albums():
        split.setdefault((norm(album['displayartist']), norm(album['title'])), []).append(album)
    split = [rows[0] for rows in split.values() if len(rows) > 1]
    plural = lambda n, word: f'{n} {word}' + ('' if n == 1 else 's')
    message = (f'Cleaned {plural(len(dirty_albums), "album")} and {plural(len(dirty_artists), "artist")}'
               + (f' ({failed} failed).' if failed else '.'))
    message += f'\nBackup: {saved.rsplit("/", 1)[-1]}' if saved else ''
    if split:
        message += (f'\n\nListed more than once: ' + '; '.join(f'{a["displayartist"]} - {a["title"]}' for a in split[:3])
                    + (f' and {len(split) - 3} more' if len(split) > 3 else '') + '.')
    dialog.ok('Clean library', message)
