"""Kodi's scraper protocol for the Minimalist Album Scraper and Minimalist Artist Scraper (the same
file is in both add-ons: change both), so the Minimalist rules apply when Kodi itself scrapes (a
scan, or Refresh).

Kodi runs the scraper add-on as a plugin with action=find (artist, title) and then
action=getdetails (the url a find result carried). Albums are looked up on TheAudioDB first and
MusicBrainz after. Only year, genre, artwork and an album's MusicBrainz release group are returned:
never a MusicBrainz release ID (per edition, so it splits albums), reviews, biographies, moods or
styles. With Kodi's "Override tags" off, as it is by default, Kodi only fills an empty year, genre
or release group and never renames an album or artist, so the tags win. Covers come largest first (square ones only), which is the one Kodi takes when the
album has no local art; artist photos and fanart likewise.

A find marks exact name matches 1.0 and anything else 0.5, so a scan only takes exact matches and
a manual Refresh lists the rest to choose from.

When the files' tags carry MusicBrainz IDs, Kodi skips find and asks action=resolveid with the
album's release ID or the artist's ID: the album is then looked up by its release group (the
release ID is never returned), the artist on TheAudioDB by their ID. Anything unknown is declined,
and Kodi goes back to searching by name.
"""
import json
import sys
from urllib.parse import parse_qsl

import xbmcaddon
import xbmcgui
import xbmcplugin

import sources

EXACT, LOOSE = '1.0', '0.5'


def api_key():
    return xbmcaddon.Addon().getSetting('fanarttv_key').strip()


def by_size(urls, need_square):
    """urls largest first, with their sizes; non-square ones left out when need_square."""
    sized = [(sources.image_size(u), u) for u in dict.fromkeys(urls)]
    sized = [(s, u) for s, u in sized if s[0] and (sources.square(s) or not need_square)]
    return [u for s, u in sorted(sized, key=lambda su: -su[0][0] * su[0][1])]


# Albums
def find_album(handle, artist, title):
    want = sources.base_title(title)
    items = []
    found = sources.search_albums(artist, sources.plain_title(title))
    matches = lambda c: (sources.same_artist(c['artist'], artist) and sources.base_title(c['title']) == want
                         and c.get('type') != 'Single')            # a single of the same name isn't the album
    # The album once: MusicBrainz's exact match is left out when TheAudioDB has it too
    if any(c['source'] == 'TheAudioDB' and matches(c) for c in found):
        found = [c for c in found if not (c['source'] == 'MusicBrainz' and matches(c))]
    for c in found:
        exact = matches(c)
        item = xbmcgui.ListItem(c['title'], offscreen=True)
        item.setArt({'thumb': (c['covers'] or [''])[0]})
        item.setProperty('album.artist', c['artist'])
        item.setProperty('album.year', c['year'])
        item.setProperty('relevance', EXACT if exact else LOOSE)
        items.append((album_url(c, artist, title), item, True))
    xbmcplugin.addDirectoryItems(handle, items)


def album_url(c, artist, title):
    return json.dumps({'source': c['source'], 'artist': c['artist'], 'title': c['title'], 'year': c['year'],
                       'genre': c['genre'], 'covers': c['covers'], 'releasegroup': c['releasegroup'],
                       'local_artist': artist, 'local_title': title})


def resolve_album(handle, release):
    found = sources.album_by_release(release) if release else None
    resolved(handle, found and album_url(found, found['artist'], found['title']))


def resolved(handle, url):
    """Answer a resolveid: the url getdetails will get, or a refusal (Kodi then searches by name)."""
    xbmcplugin.setResolvedUrl(handle, bool(url), xbmcgui.ListItem(path=url or '', offscreen=True))


def parse(url):
    """A url this scraper made, or None (anything else, Kodi's own guesses included)."""
    try:
        found = json.loads(url)
    except ValueError:
        return None
    return found if isinstance(found, dict) else None


def album_details(handle, url):
    found = parse(url)
    if not found or 'title' not in found:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem(offscreen=True))
        return
    candidates = [found]
    candidates += sources.apple_covers(found['local_artist'] or found['artist'], found['local_title'] or found['title'], 0)
    candidates += sources.fanart_candidates([found], found['artist'], found['title'], api_key())
    item = xbmcgui.ListItem(found['local_title'] or found['title'], offscreen=True)
    if found['year'][:4].isdigit():
        item.setProperty('album.year', found['year'][:4])
        item.setProperty('album.releasedate', found['year'][:4])
    if found['genre']:
        item.setProperty('album.genre', found['genre'])
    # The release group (every edition of the album) but never a release ID, which is per edition
    # and splits an album whose files carry different ones
    if found['releasegroup']:
        item.setProperty('album.releasegroupid', found['releasegroup'])
    covers = by_size([u for c in candidates for u in c['covers']], True)
    item.setProperty('album.thumbs', str(len(covers)))
    for n, cover in enumerate(covers, 1):
        item.setProperty(f'album.thumb{n}.url', cover)
        item.setProperty(f'album.thumb{n}.aspect', 'thumb')
    xbmcplugin.setResolvedUrl(handle, True, item)


# Artists
def find_artist(handle, artist):
    items = []
    found = sources.tadb_artist(artist)
    # Without TheAudioDB, fanart.tv is the only other source, and it needs the MusicBrainz ID
    mbid = (found or {}).get('mbid') or (sources.musicbrainz_artist(artist) if api_key() else '')
    if found or mbid:
        item = xbmcgui.ListItem(artist, offscreen=True)
        item.setArt({'thumb': ((found or {}).get('thumb') or [''])[0]})
        item.setProperty('artist.genre', (found or {}).get('genre', ''))
        item.setProperty('relevance', EXACT)
        items.append((json.dumps({'artist': artist, 'mbid': mbid, 'tadb': found or {}}), item, True))
    xbmcplugin.addDirectoryItems(handle, items)


def resolve_artist(handle, mbid):
    found = sources.tadb_artist_by_mbid(mbid) if mbid else None
    name = (found or {}).get('artist') or (sources.musicbrainz_artist_name(mbid) if mbid and api_key() else '')
    resolved(handle, name and json.dumps({'artist': name, 'mbid': mbid, 'tadb': found or {}}))


def artist_details(handle, url):
    found = parse(url)
    if not found or 'artist' not in found:
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem(offscreen=True))
        return
    tadb = found['tadb'] or {}
    fanart = sources.fanart_artist(found['mbid'], api_key())
    item = xbmcgui.ListItem(found['artist'], offscreen=True)
    if tadb.get('genre'):
        item.setProperty('artist.genre', tadb['genre'])
    art = [(u, 'thumb') for u in by_size(tadb.get('thumb', []) + fanart['thumb'], True)]
    art += [(u, 'fanart') for u in by_size(tadb.get('fanart', []) + fanart['fanart'], False)]
    item.setProperty('artist.thumbs', str(len(art)))
    for n, (image, aspect) in enumerate(art, 1):
        item.setProperty(f'artist.thumb{n}.url', image)
        item.setProperty(f'artist.thumb{n}.aspect', aspect)
    xbmcplugin.setResolvedUrl(handle, True, item)


def run(kind):
    handle = int(sys.argv[1])
    params = dict(parse_qsl(sys.argv[2].lstrip('?')))
    action = params.get('action')
    # NfoUrl (a url in an .nfo file) isn't supported: Kodi then searches by name
    if kind == 'albums' and action == 'find':
        find_album(handle, params.get('artist', ''), params.get('title', ''))
    elif kind == 'albums' and action == 'getdetails':
        album_details(handle, params.get('url', '{}'))
    elif kind == 'albums' and action == 'resolveid':
        resolve_album(handle, params.get('key', ''))
    elif kind == 'artists' and action == 'find':
        find_artist(handle, params.get('artist', ''))
    elif kind == 'artists' and action == 'getdetails':
        artist_details(handle, params.get('url', '{}'))
    elif kind == 'artists' and action == 'resolveid':
        resolve_artist(handle, params.get('key', ''))
    xbmcplugin.endOfDirectory(handle)
