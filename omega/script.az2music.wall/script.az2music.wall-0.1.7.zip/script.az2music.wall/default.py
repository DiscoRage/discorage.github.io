"""Artist Wall columns for skin.az2music.

The skin's wall is one horizontal list in which every item is a column of ROWS artists, so the
whole wall pans together under a fixed highlight. Artists fill each column top to bottom, then
the next column, so the wall reads alphabetically from left to right.

Called by the skin as
plugin://script.az2music.wall/?rows=5&cols=7&rest=3&row0=7310&bar0=7401&path=<music library folder>
(path last and unparsed, since library paths can carry their own query string). cols is how many
columns fit on screen, rest the screen column the highlight rests on while the wall pans, and
row0 the id of the skin's first row button and bar0 that of its # letter button.

The list starts with an empty column, where the skin keeps its selected item, then the artists'.
Each column item has properties name<r>, thumb<r>, fanart<r>, genre<r>, path<r> and letter<r>
(the id of the artist's letter button: bar0 for #, then A-Z) for rows r = 0..ROWS-1, plus
index (its place in the list, so 1 for the first artists' column) and count (artists in the
column).

For the letter bar it also sets Home window properties az2_wall_jump_<n>_col, _shift, _focus, _hl,
_d1 and _d2 for n = 0..26: the column to select, the highlight's screen column, the row button to
focus, and the indexes of the highlighted column and of the two the panel covers, to land on that letter's first artist (or the next letter's,
if it has none).

An empty path (the skin passes one when the wall isn't showing) lists nothing.

Each artist also has a dbid<r> property, for the skin to open their information screen.
"""
import json
import math
import re
import string
import sys
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

ADDON = 'script.az2music.wall'
LETTERS = '#' + string.ascii_uppercase


def rpc(method, **params):
    result = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    if 'error' in result:
        xbmc.log(f'[{ADDON}] {method}: {result["error"]}', xbmc.LOGWARNING)
        return {}
    return result.get('result', {})


def unwrap(url):
    """JSON-RPC wraps art as image://<quoted url>/. Hand the skin the plain URL: the background's
    multiimage reads the wrapped form as a folder and can't open it."""
    if url.startswith('image://'):
        return urllib.parse.unquote(url[len('image://'):].rstrip('/'))
    return url


def letter(name, ignore_the):
    """Place in the letter bar, filed as Kodi sorts: "The X" under X when articles are ignored."""
    if ignore_the and name[:4].lower() == 'the ':
        name = name[4:]
    first = name[:1].upper()
    return LETTERS.index(first) if first in LETTERS[1:] else 0


def artists(path, bar0):
    """The folder's artists in Kodi's order: by sort name when "Use artist sort name" is on (as the
    other views have them), articles ignored when that's on. Each is filed under the first letter
    of the name it sorts by."""
    ignore_the = bool(rpc('Settings.GetSettingValue', setting='filelists.ignorethewhensorting').get('value', True))
    use_sortname = bool(rpc('Settings.GetSettingValue', setting='musiclibrary.useartistsortname').get('value', False))
    items = rpc('Files.GetDirectory', directory=path, media='music', properties=['art', 'genre'],
                sort={'method': 'artist', 'order': 'ascending', 'ignorearticle': ignore_the,
                      'useartistsortname': use_sortname}).get('files') or []
    # A folder listing doesn't carry sort names, so they come from the library in one go.
    sortnames = {}
    if use_sortname:
        for artist in rpc('AudioLibrary.GetArtists', properties=['sortname'], albumartistsonly=False).get('artists') or []:
            sortnames[artist['artistid']] = artist.get('sortname') or ''
    for item in items:
        if item.get('filetype') != 'directory' or re.search(r'/-1/', item.get('file', '')):
            continue
        art = item.get('art') or {}
        name = item.get('label', '')
        filed = sortnames.get(item.get('id')) or name
        yield {'name': name, 'thumb': unwrap(art.get('thumb', '')), 'fanart': unwrap(art.get('fanart', '')),
               'genre': ' • '.join(item.get('genre') or []),
               'path': item.get('file', ''), 'letter': str(bar0 + letter(filed, ignore_the)),
               'dbid': str(item.get('id', ''))}


def set_jumps(found, rows, cols, rest, row0):
    """Where each letter starts. The highlight rests on screen column rest where it can, as it
    does while the wall pans, and goes nearer the edge only at the start and end of the wall."""
    home = xbmcgui.Window(10000)
    columns = math.ceil(len(found) / rows)
    firsts = {}
    for i, artist in enumerate(found):
        firsts.setdefault(artist['n'], i)
    target = len(found) - 1
    for n in reversed(range(len(LETTERS))):
        target = firsts.get(n, target)          # a letter with no artists jumps to the next that has
        c, r = divmod(max(target, 0), rows)
        col = max(0, min(c - rest, columns - cols))
        home.setProperty(f'az2_wall_jump_{n}_col', str(col))
        home.setProperty(f'az2_wall_jump_{n}_shift', str(c - col))
        home.setProperty(f'az2_wall_jump_{n}_focus', str(row0 + r))
        home.setProperty(f'az2_wall_jump_{n}_hl', str(c + 1))           # list places, after the empty column
        drawer = (c + 1, c + 2) if c - col < rest else (c - 1, c - 2)    # the columns the skin's panel covers
        home.setProperty(f'az2_wall_jump_{n}_d1', str(drawer[0] + 1))
        home.setProperty(f'az2_wall_jump_{n}_d2', str(drawer[1] + 1))


def main():
    handle = int(sys.argv[1])
    query, _, path = sys.argv[2].lstrip('?').partition('path=')
    args = dict(urllib.parse.parse_qsl(query))
    rows = max(1, int(args.get('rows', 5)))
    bar0 = int(args.get('bar0', 7401))
    found = list(artists(path, bar0)) if path else []
    for artist in found:
        artist['n'] = int(artist['letter']) - bar0
    if found:
        set_jumps(found, rows, int(args.get('cols', 7)), int(args.get('rest', 3)), int(args.get('row0', 7310)))

    # The empty column first: the skin keeps its selected item there, just off screen.
    columns = []
    if found:
        lead = xbmcgui.ListItem(offscreen=True)
        lead.setProperties({'index': '0', 'count': '0'})
        columns.append((f'plugin://{ADDON}/?column=lead', lead, False))
    for c in range(math.ceil(len(found) / rows)):
        cells = found[c * rows:(c + 1) * rows]
        props = {'index': str(c + 1), 'count': str(len(cells))}
        for r, artist in enumerate(cells):
            props.update({f'{key}{r}': value for key, value in artist.items() if key != 'n'})
        item = xbmcgui.ListItem(label=cells[0]['name'], offscreen=True)
        item.setProperties(props)
        columns.append((f'plugin://{ADDON}/?column={c}', item, False))

    xbmcplugin.addDirectoryItems(handle, columns, len(columns))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


main()
