# Arctic Zephyr 2: Music Edition

A music-first Arctic Zephyr 2 for Kodi 21. Source, install instructions and credits:
https://github.com/DiscoRage/Arctic-Zephyr-2-Music-Edition

Based on Arctic Zephyr 2: Resurrection by DenDyGH and heppen, which builds on Arctic Zephyr 2
by jurialmunkey as ported to Kodi 19 by pkscout.

Licence: Creative Commons BY-NC-SA 4.0 (see LICENSE.txt).
