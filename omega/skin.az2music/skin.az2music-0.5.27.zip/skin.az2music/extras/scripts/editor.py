"""Artist editing for the skin's artist information screen (DialogMusicInfo_Artist).

The edit panel runs this from the skin folder and shows its state from Home window properties:

  RunScript(special://skin/extras/scripts/editor.py,open,<artistid>)   load the artist's fields
  RunScript(special://skin/extras/scripts/editor.py,edit,<field>)      type a new value (artist, sortname, genre)
  RunScript(special://skin/extras/scripts/editor.py,save)              write the changed fields, reopen the screen
  RunScript(special://skin/extras/scripts/editor.py,close)             drop any changes
  RunScript(special://skin/extras/scripts/editor.py,info,<artistid>)   open the screen itself

Properties: az2_edit_id (the artist), az2_edit_val_<field> (the value shown: changed or current),
az2_edit_chg_<field> (set when changed) and az2_edit_dirty (set when anything is). Changes go
through AudioLibrary.SetArtistDetails, so Kodi writes them into its music database itself. A save also
bumps az2_wall_rev, which the Artist Wall's source address carries, so the wall reloads.

Genres are edited as one line, " / " between them, as Kodi shows them.
"""
import json
import re
import sys
import time

import xbmc
import xbmcgui

LOG = '[skin.az2music] editor'
FIELDS = {'artist': 'Name', 'sortname': 'Sort name', 'genre': 'Genre'}
HOME = xbmcgui.Window(10000)


def rpc(method, **params):
    result = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    if 'error' in result:
        raise RuntimeError(f'{method}: {result["error"].get("message", result["error"])}')
    return result.get('result', {})


def as_text(value):
    return ' / '.join(v for v in value if v) if isinstance(value, list) else (value or '')


def current(artistid):
    details = rpc('AudioLibrary.GetArtistDetails', artistid=artistid, properties=['sortname', 'genre'])['artistdetails']
    return {'artist': as_text(details.get('artist') or details.get('label')),
            'sortname': as_text(details.get('sortname')),
            'genre': as_text(details.get('genre'))}


def clear():
    for prop in ['az2_edit_id', 'az2_edit_dirty'] + [f'az2_edit_{k}_{f}' for f in FIELDS for k in ('val', 'chg', 'cur')]:
        HOME.clearProperty(prop)


def open_artist(artistid):
    clear()
    HOME.setProperty('az2_edit_id', str(artistid))
    for field, value in current(artistid).items():
        HOME.setProperty(f'az2_edit_cur_{field}', value)
        HOME.setProperty(f'az2_edit_val_{field}', value)


def edit(field):
    if field not in FIELDS or not HOME.getProperty('az2_edit_id'):
        return
    keyboard = xbmc.Keyboard(HOME.getProperty(f'az2_edit_val_{field}'), FIELDS[field])
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return
    value = keyboard.getText().strip()
    if field == 'genre':
        value = ' / '.join(g.strip() for g in re.split(r'\s*/\s*', value) if g.strip())
    if field != 'genre' and not value:
        xbmcgui.Dialog().notification(FIELDS[field], 'Left as it was: it can\'t be empty.', xbmcgui.NOTIFICATION_WARNING)
        return
    HOME.setProperty(f'az2_edit_val_{field}', value)
    if value == HOME.getProperty(f'az2_edit_cur_{field}'):
        HOME.clearProperty(f'az2_edit_chg_{field}')
    else:
        HOME.setProperty(f'az2_edit_chg_{field}', '1')
    if any(HOME.getProperty(f'az2_edit_chg_{f}') for f in FIELDS):
        HOME.setProperty('az2_edit_dirty', '1')
    else:
        HOME.clearProperty('az2_edit_dirty')


def save():
    artistid = HOME.getProperty('az2_edit_id')
    changed = {f: HOME.getProperty(f'az2_edit_val_{f}') for f in FIELDS if HOME.getProperty(f'az2_edit_chg_{f}')}
    if not artistid or not changed:
        clear()
        return
    if 'genre' in changed:
        changed['genre'] = [g for g in changed['genre'].split(' / ') if g]
    rpc('AudioLibrary.SetArtistDetails', artistid=int(artistid), **changed)
    clear()
    HOME.setProperty('az2_wall_rev', str(int(time.time())))
    # Reopen the screen so it shows the library's new details, from another run of this script
    # (see info), so this one ends here rather than waiting on the screen. No Container.Refresh:
    # the wall reloads by az2_wall_rev.
    xbmc.executebuiltin('Dialog.Close(musicinformation)')
    xbmc.sleep(300)
    xbmc.executebuiltin(f'RunScript(special://skin/extras/scripts/editor.py,info,{artistid})')


def info(artistid):
    """Kodi's artist information screen for library artist artistid: the wall's Info key, and
    the reopening after a save. The view behind the wall never knows which artist is
    highlighted, so Info can't reach it. A skin script rather than a plugin: while a plugin
    holds the screen open, the window counts as that plugin's and the wall's view hides."""
    item = xbmcgui.ListItem(path=f'musicdb://artists/{artistid}/', offscreen=True)
    item.setIsFolder(True)
    item.getMusicInfoTag().setDbId(int(artistid), 'artist')
    xbmcgui.Dialog().info(item)


def main(args):
    command = args[0] if args else ''
    try:
        if command == 'open' and len(args) > 1 and args[1].isdigit():
            open_artist(int(args[1]))
        elif command == 'edit' and len(args) > 1:
            edit(args[1])
        elif command == 'save':
            save()
        elif command == 'close':
            clear()
        elif command == 'info' and len(args) > 1 and args[1].isdigit():
            info(int(args[1]))
    except Exception as exc:
        xbmc.log(f'{LOG}: {command}: {exc}', xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Artist not saved', str(exc), xbmcgui.NOTIFICATION_ERROR)


main(sys.argv[1:])
