"""One line describing an album's audio, read from the header of its first track.

Called by the skin as plugin://script.az2music.wall/?audio=<albumid>. Lists one item whose label
is the line, e.g. "TrueHD Atmos • 48 kHz", "DSD64 • 5.1" or "FLAC • 24 bit • 96 kHz • 5.1", with
the album id as property album (so the skin can tell an answer for the album it has just left).

Only the first few KB of the file are read: the FLAC, DSF or WAV header, or for M4A the sample
description and the first TrueHD frame. Kodi's library doesn't store codec or bit depth, and has
nothing at all for TrueHD, E-AC3 or DSD files. Lines are kept in addon_data, by file, so each album
is read once.
"""
import json
import os
import struct

import xbmc
import xbmcvfs

CACHE = 'special://profile/addon_data/script.az2music.wall/audio.json'

EC3_RATES = {0: 48000, 1: 44100, 2: 32000}
ACMOD_CH = {0: 2, 1: 1, 2: 2, 3: 3, 4: 3, 5: 4, 6: 4, 7: 5}
EC3_DEP_CH = [2, 2, 1, 1, 2, 2, 2, 1, 1]                 # chan_loc bits, first bit first
THD_RATES = {0: 48000, 1: 96000, 2: 192000, 8: 44100, 9: 88200, 10: 176400}
THD_CH = [2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 1, 1]          # FFmpeg's thd_chancount, bit 0 first
DSF_LAYOUT = {1: 'Mono', 2: '2.0', 3: '3.0', 4: 'Quad', 5: '4.0', 6: '5.0', 7: '5.1'}


class Bits:
    def __init__(self, data):
        self.data, self.pos = data, 0

    def read(self, n):
        v = 0
        for _ in range(n):
            v = (v << 1) | ((self.data[self.pos // 8] >> (7 - self.pos % 8)) & 1)
            self.pos += 1
        return v

    def left(self):
        return len(self.data) * 8 - self.pos


class File:
    """xbmcvfs.File with plain seek/read, so library paths (smb://, nfs://) work."""
    def __init__(self, path):
        self.f = xbmcvfs.File(path)
        self.size = self.f.size()

    def read(self, n, at=None):
        if at is not None:
            self.f.seek(at, 0)
        return bytes(self.f.readBytes(n))

    def close(self):
        self.f.close()


def khz(hz):
    return f'{hz / 1000:g} kHz'


def channels(n):
    return {1: 'Mono', 2: '', 6: '5.1', 8: '7.1'}.get(n, f'{n} ch')


def line(*parts):
    return ' • '.join(p for p in parts if p)


# MP4 boxes: (type, payload start, box end), found by seeking from header to header.
def boxes(f, start, end):
    pos = start
    while pos + 8 <= end:
        head = f.read(16, pos)
        size, kind = struct.unpack('>I4s', head[:8])
        header = 8
        if size == 1:
            size, header = struct.unpack('>Q', head[8:16])[0], 16
        elif size == 0:
            size = end - pos
        if size < header:
            return
        yield kind, pos + header, pos + size
        pos += size


def box(f, start, end, *path):
    for name in path:
        for kind, s, e in boxes(f, start, end):
            if kind == name:
                start, end = s, e
                break
        else:
            return None
    return start, end


def truehd(au):
    """The major sync at the start of the first frame. Atmos is its 16-channel presentation."""
    sync = au.find(b'\xf8\x72\x6f\xba')
    if sync < 0:
        return 'TrueHD'
    b = Bits(au[sync + 4:])
    rate = THD_RATES.get(b.read(4))
    b.read(4 + 2 + 2 + 5 + 2)
    arr = b.read(13)                                    # the 8-channel presentation's layout
    b.read(16 + 16 + 16 + 16 + 4 + 2 + 2)
    if b.read(8) >> 7 & 1:
        return line('TrueHD Atmos', rate and khz(rate))
    lfe = (arr >> 2 & 1) + (arr >> 12 & 1)
    total = sum(THD_CH[i] for i in range(13) if arr >> i & 1)
    return line('TrueHD', rate and khz(rate), f'{total - lfe}.{lfe}')


def dec3(payload):
    """E-AC3 setup. Atmos is JOC, signalled by a complexity index after the substreams."""
    b = Bits(payload)
    b.read(13)
    total, lfe, rate = 0, 0, None
    for _ in range(b.read(3) + 1):
        fscod = b.read(2)
        b.read(5 + 1 + 1 + 3)
        acmod, lfeon = b.read(3), b.read(1)
        b.read(3)
        if b.read(4):
            loc = b.read(9)
            total += sum(n for i, n in enumerate(EC3_DEP_CH) if loc >> (8 - i) & 1)
        else:
            b.read(1)
        rate = rate or EC3_RATES.get(fscod)
        total, lfe = total + ACMOD_CH[acmod], lfe or lfeon
    if b.left() >= 16:
        b.read(7)
        if b.read(1) and b.read(8):
            return line('DD+ Atmos', rate and khz(rate))
    return line('DD+', rate and khz(rate), f'{total}.{lfe}')


def mp4(f):
    moov = box(f, 0, f.size, b'moov')
    trak = moov and box(f, *moov, b'trak')
    stbl = trak and box(f, *trak, b'mdia', b'minf', b'stbl')
    stsd = stbl and box(f, *stbl, b'stsd')
    if not stsd:
        return ''
    kind, start, end = next(boxes(f, stsd[0] + 8, stsd[1]))
    entry = f.read(28, start)                            # AudioSampleEntry, then its boxes
    if kind == b'mlpa':
        for name, fmt in ((b'stco', '>I'), (b'co64', '>Q')):
            offsets = box(f, *stbl, name)
            if offsets:
                first = struct.unpack(fmt, f.read(struct.calcsize(fmt), offsets[0] + 8))[0]
                return truehd(f.read(64, first))
    for name, s, e in boxes(f, start + 28, end):
        if name == b'dec3' and kind == b'ec-3':
            return dec3(f.read(e - s, s))
        if name == b'alac' and kind == b'alac':
            config = f.read(24, s + 4)
            return line('ALAC', f'{config[5]} bit', khz(struct.unpack('>I', config[20:24])[0]),
                        channels(config[9]))
    rate = struct.unpack('>I', entry[24:28])[0] >> 16
    return line({b'ec-3': 'DD+', b'ac-3': 'DD', b'mp4a': 'AAC'}.get(kind, kind.decode('latin-1').strip()),
                rate and khz(rate))


def flac(f):
    h = f.read(42)
    if h[:3] == b'ID3':                                  # some taggers put an ID3 tag first
        size = (h[6] << 21 | h[7] << 14 | h[8] << 7 | h[9]) + (20 if h[5] & 0x10 else 10)
        h = f.read(42, size)
    if h[:4] != b'fLaC':
        return ''
    v = struct.unpack('>Q', h[18:26])[0]
    return line('FLAC', f'{((v >> 36) & 0x1F) + 1} bit', khz((v >> 44) & 0xFFFFF), channels(((v >> 41) & 7) + 1))


def dsf(f):
    h = f.read(64)
    if h[:4] != b'DSD ':
        return ''
    _, _, layout, count, rate, _ = struct.unpack('<6I', h[40:64])
    return line(f'DSD{rate // 44100}', DSF_LAYOUT.get(layout, f'{count} ch'))


def wav(f):
    h = f.read(4096)
    at = h.find(b'fmt ')
    if h[:4] != b'RIFF' or at < 0:
        return ''
    count, rate = struct.unpack('<HI', h[at + 10:at + 16])
    bits = struct.unpack('<H', h[at + 22:at + 24])[0]
    return line('WAV', f'{bits} bit', khz(rate), channels(count))


READERS = {'.flac': flac, '.dsf': dsf, '.m4a': mp4, '.mp4': mp4, '.wav': wav}


def describe(song):
    path = song.get('file', '')
    ext = os.path.splitext(path)[1].lower()
    reader = READERS.get(ext)
    if reader:
        f = File(path)
        try:
            return reader(f)
        finally:
            f.close()
    # Anything else (MP3, OGG...) has what's worth showing in the library already.
    return line(ext.lstrip('.').upper(), song.get('bitrate') and f'{song["bitrate"]} kbps',
                song.get('samplerate') and khz(song['samplerate']))


def album_line(rpc, album_id):
    songs = rpc('AudioLibrary.GetSongs', filter={'albumid': int(album_id)},
                properties=['file', 'bitrate', 'samplerate'], limits={'start': 0, 'end': 1},
                sort={'method': 'track'}).get('songs') or []
    if not songs:
        return ''
    path = songs[0]['file']
    cache_file = xbmcvfs.translatePath(CACHE)
    try:
        with open(cache_file, encoding='utf-8') as f:
            cache = json.load(f)
    except (OSError, ValueError):
        cache = {}
    if path not in cache:
        try:
            text = describe(songs[0])
        except Exception as exc:                          # an unreadable file shows nothing
            xbmc.log(f'[script.az2music.wall] audio {path}: {exc!r}', xbmc.LOGWARNING)
            return ''
        if not text:
            return ''
        cache[path] = text
        os.makedirs(os.path.dirname(cache_file), exist_ok=True)
        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(cache, f, ensure_ascii=False)
    return cache[path]
