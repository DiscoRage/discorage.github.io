"""Now Playing for skin.az2music: the cover's colour, the blurred background and the album's tracks.

plugin://script.az2music.wall/?nowplaying=<songid>&file=<the playing file>
    Lists one item with properties song and file (the song id and file, so the skin can tell an
    answer for the track it is on) and atmos (set for Atmos, read from the file as the album views'
    audio line is). A file played from a folder has no song id: then the file is read instead.
    Then, when the cover has changed, the cover's art (see refresh_art).
plugin://script.az2music.wall/?blur=1
    The playing cover's art again, blur included (the skin's Background switch turning it on).
plugin://script.az2music.wall/?cover=next and ?wall=next
    The album's next cover (folder.jpg, folder1.jpg...) or wallpaper (wallpaper.jpg,
    wallpaper1.jpg...), for Now Playing only, remembered for the album (see artwork).
plugin://script.az2music.wall/?tracks=<songid>
    The song's album, track by track: label the title, label2 the length, properties number,
    playing (on the playing track), song and total (the album's length); then moves the skin's
    list (5800) to the playing track once it has them.
plugin://script.az2music.wall/?play=<songid>
    Jump to that track: in the playlist when it is there, otherwise play its album from it.
"""
import colorsys
import hashlib
import io
import json
import re
import urllib.parse
from collections import Counter

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

import audio

HOME = xbmcgui.Window(10000)
FALLBACK = 'FFF0C24B'
BLURS = 'special://profile/addon_data/script.az2music.wall/blur/'
BLUR_SIZE, BLUR_RADIUS, BLURS_KEPT = 480, 40, 300      # TMDb Helper's blur, as the skin used to have
VERSION = re.compile(r'^(folder|wallpaper)(\d*)\.(jpe?g|png)$', re.I)    # folder.jpg, wallpaper2.png...
CHOICES = 'special://profile/addon_data/script.az2music.wall/choices.json'
DISC = re.compile(r'^(cd|dis[ck])\s*[-_.]?\s*\d+$', re.I)   # a disc's own folder: CD1, Disc 2, disk-3...


def log(message, level=xbmc.LOGINFO):
    xbmc.log(f'[script.az2music.wall] {message}', level)


# Colour: the most vivid, common colour of the cover (as service.progressbarcolour picked it)
def hex_rgb(rgb):
    return 'FF{:02X}{:02X}{:02X}'.format(*rgb)


def adjust(colour, sat=1.0, val=1.0):
    r, g, b = (int(colour[i:i + 2], 16) / 255 for i in (2, 4, 6))
    h, s, v = colorsys.rgb_to_hsv(r, g, b)
    rgb = colorsys.hsv_to_rgb(h, max(0.18, min(0.92, s * sat)), max(0.42, min(0.92, v * val)))
    return hex_rgb(tuple(max(0, min(255, round(c * 255))) for c in rgb))


def cover_image(rpc, cover):
    """The cover, decoded no bigger than the blur needs: Kodi's cached copy when it has one (local
    and already shrunk), else the original. None if neither opens."""
    from PIL import Image
    paths = []
    plain = urllib.parse.unquote(cover[len('image://'):].rstrip('/')) if cover.startswith('image://') else cover
    for url in dict.fromkeys((cover, plain)):
        found = rpc('Textures.GetTextures', filter={'field': 'url', 'operator': 'is', 'value': url},
                    properties=['cachedurl']).get('textures') or []
        paths += [f"special://profile/Thumbnails/{t['cachedurl']}" for t in found if t.get('cachedurl')]
    for path in paths + [cover]:
        try:
            f = xbmcvfs.File(path)
            data = bytes(f.readBytes())
            f.close()
            img = Image.open(io.BytesIO(data))
            img.draft('RGB', (BLUR_SIZE, BLUR_SIZE))      # JPEG decodes small, which is most of the work
            return img.convert('RGB')
        except Exception as exc:
            log(f'cover {path}: {exc!r}', xbmc.LOGWARNING)
    return None


def cover_colour(img):
    if img is None:
        return FALLBACK
    img = img.copy()
    img.thumbnail((96, 96))
    counts, weights = Counter(), Counter()
    pixels = list(img.getdata())
    for px in pixels:
        h, s, v = colorsys.rgb_to_hsv(*(c / 255 for c in px))
        if 0.12 <= v <= 0.95 and s >= 0.18:
            bucket = tuple(min(255, round(c / 24) * 24) for c in px)
            counts[bucket] += 1
            weights[bucket] += s * 2.3 + 1.0 - abs(v - 0.62)
    if not counts:
        mean = tuple(int(sum(px[i] for px in pixels) / len(pixels)) for i in range(3))
        return adjust(hex_rgb(mean), 1.15, 0.95)
    best = max(counts, key=lambda b: (weights[b], counts[b]))
    return adjust(hex_rgb(best), 1.10, 0.95)


def blur(img, cover):
    """The blurred cover, saved once per cover in addon_data; '' if it can't be made. Saved as PNG
    with an alpha channel: Kodi caches images without one as JPEG, whose blocks the screen then
    stretches four times over (blocky on dark covers)."""
    from PIL import ImageFilter
    path = f'{BLURS}{hashlib.md5(cover.encode("utf-8")).hexdigest()}.png'
    if xbmcvfs.exists(path):
        return path
    try:
        small = img.copy()
        small.thumbnail((BLUR_SIZE, BLUR_SIZE))
        small = small.filter(ImageFilter.GaussianBlur(BLUR_RADIUS)).convert('RGBA')
        small.putpixel((0, 0), small.getpixel((0, 0))[:3] + (254,))  # an alpha Kodi can't overlook
        data = io.BytesIO()
        small.save(data, 'PNG')
        xbmcvfs.mkdirs(BLURS)
        with xbmcvfs.File(path, 'w') as f:
            f.write(bytearray(data.getvalue()))
    except Exception as exc:
        log(f'blur {cover}: {exc!r}', xbmc.LOGWARNING)
        return ''
    prune()
    return path


def prune():
    _, files = xbmcvfs.listdir(BLURS)
    if len(files) > BLURS_KEPT:
        dated = sorted(files, key=lambda f: xbmcvfs.Stat(BLURS + f).st_mtime())
        for name in dated[:len(files) - BLURS_KEPT]:
            xbmcvfs.delete(BLURS + name)


def album_places(file):
    """Where the playing file's album keeps its art: its folder, and for a disc's folder (CD1...)
    the album's, one up. None for what isn't a file in a folder."""
    cut = max(file.rfind('/'), file.rfind('\\'))
    if cut < 0 or file.startswith(('plugin://', 'musicdb://', 'pvr://', 'http://', 'https://')):
        return []
    folder = file[:cut + 1]
    places = [folder]
    name = folder.rstrip('/\\')
    up = max(name.rfind('/'), name.rfind('\\'))
    if up >= 0 and DISC.match(name[up + 1:]):
        places.append(name[:up + 1])
    return places


def artwork(file):
    """The album's covers and wallpapers, each in order (folder.jpg, folder1.jpg, folder2.jpg...;
    .jpg before .png for a number that has both), and the folder the album's choice is kept under.
    One listing per folder."""
    found = {'folder': {}, 'wallpaper': {}}
    places = album_places(file)
    for place in places:
        try:
            _, files = xbmcvfs.listdir(place)
        except Exception:
            continue
        for name in files:
            m = VERSION.match(name)
            if m:
                number = int(m.group(2) or 0)
                kind = found[m.group(1).lower()]
                if number not in kind or (kind[number][1] == 'png' and m.group(3).lower() != 'png'):
                    kind[number] = (place + name, m.group(3).lower())
    covers = [found['folder'][n][0] for n in sorted(found['folder'])]
    walls = [found['wallpaper'][n][0] for n in sorted(found['wallpaper'])]
    return covers, walls, (places[-1] if places else '')


def load_choices():
    try:
        with xbmcvfs.File(CHOICES) as f:
            return json.loads(f.read() or '{}')
    except Exception:
        return {}


def step(kind):
    """Move the playing album on to its next cover or wallpaper, and show it."""
    covers, walls, album = artwork(xbmc.getInfoLabel('Player.FilenameAndPath'))
    versions = covers if kind == 'cover' else walls
    if not album or len(versions) < 2:
        return
    choices = load_choices()
    picks = choices.setdefault(album, {})
    picks[kind] = (picks.get(kind, 0) + 1) % len(versions)
    xbmcvfs.mkdirs(CHOICES.rsplit('/', 1)[0] + '/')
    with xbmcvfs.File(CHOICES, 'w') as f:
        f.write(json.dumps(choices, indent=1))


def refresh_art(rpc, force=False):
    """For the playing cover, when it, the album's art or a choice of it has changed (or force):
    Home properties
      az2_np_wall      the album's wallpaper (the chosen one), '' without one; set first, as the
                       skin's view depends on it; az2_np_walls / az2_np_walli: how many, which
      az2_np_coverart  the chosen cover when it isn't the first ('' for the library's own);
                       az2_np_covers / az2_np_coveri: how many, which
      MusicArtColor, MusicArtColorDark and MusicArtColorLight: a vivid colour from the cover
                       shown, in every view; gold without one
      az2_np_blur      the blurred cover, unless the skin has NowPlaying.NoBlur
      az2_np_cover     the library cover all that is for, set last: the skin shows the blur and
                       chosen cover only while it is the playing one."""
    cover = xbmc.getInfoLabel('MusicPlayer.Cover')
    if not cover:
        return
    covers, walls, album = artwork(xbmc.getInfoLabel('Player.FilenameAndPath'))
    picks = load_choices().get(album, {}) if album else {}
    ci = picks.get('cover', 0) % len(covers) if covers else 0
    wi = picks.get('wall', 0) % len(walls) if walls else 0
    wall = walls[wi] if walls else ''
    coverart = covers[ci] if ci else ''
    key = f'{cover}|{wall}|{coverart}'
    if key == HOME.getProperty('az2_np_key') and not force:
        return
    HOME.setProperty('az2_np_key', key)
    for name, value in (('az2_np_wall', wall), ('az2_np_walls', len(walls)), ('az2_np_walli', wi + 1),
                        ('az2_np_coverart', coverart), ('az2_np_covers', len(covers)),
                        ('az2_np_coveri', ci + 1)):
        HOME.setProperty(name, str(value))
    if not wall and HOME.getProperty('NP_WallCentre'):
        # Dropped back to Default: once the cover has started back (late, from the centre), it
        # is on the left for the next album with a wallpaper too
        xbmc.sleep(300)
        HOME.clearProperty('NP_WallCentre')
    shown = coverart or cover
    img = None if shown.lower().startswith('default') else cover_image(rpc, shown)
    colour = cover_colour(img)
    HOME.setProperty('MusicArtColor', colour)
    HOME.setProperty('MusicArtColorDark', adjust(colour, 0.95, 0.70))
    HOME.setProperty('MusicArtColorLight', adjust(colour, 0.90, 1.12))
    if img is not None and not xbmc.getCondVisibility('Skin.HasSetting(NowPlaying.NoBlur)'):
        HOME.setProperty('az2_np_blur', blur(img, shown))
    if cover == xbmc.getInfoLabel('MusicPlayer.Cover'):     # still playing: not overtaken by a skip
        HOME.setProperty('az2_np_cover', cover)


def now_playing(handle, rpc, song_id, file=''):
    item = xbmcgui.ListItem(offscreen=True)
    item.setProperties({'song': song_id, 'file': file})
    if song_id.isdigit():
        song = rpc('AudioLibrary.GetSongDetails', songid=int(song_id),
                   properties=['file', 'bitrate', 'samplerate', 'datemodified']).get('songdetails')
    else:
        song = {'file': file} if file else None
    if song and 'Atmos' in audio.song_line(song):
        item.setProperty('atmos', '1')
    xbmcplugin.addDirectoryItem(handle, f'plugin://script.az2music.wall/?nowplaying={song_id}', item, False)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
    refresh_art(rpc)                    # after the listing, which needn't wait for it


def length(seconds):
    return f'{seconds // 3600}:{seconds // 60 % 60:02d}:{seconds % 60:02d}' if seconds >= 3600 else f'{seconds // 60}:{seconds % 60:02d}'


def album_songs(rpc, song_id):
    song = rpc('AudioLibrary.GetSongDetails', songid=int(song_id), properties=['albumid']).get('songdetails') or {}
    if not song.get('albumid'):
        return []
    return rpc('AudioLibrary.GetSongs', filter={'albumid': song['albumid']},
               properties=['title', 'track', 'duration'], sort={'method': 'track'}).get('songs') or []


def tracks(handle, rpc, song_id):
    songs = album_songs(rpc, song_id) if song_id.isdigit() else []
    total = length(sum(s.get('duration') or 0 for s in songs))
    items = []
    for song in songs:
        item = xbmcgui.ListItem(label=song['title'], label2=length(song.get('duration') or 0), offscreen=True)
        item.setProperties({'number': f"{song.get('track', 0) % 65536:02d}", 'song': str(song['songid']),
                            'playing': '1' if str(song['songid']) == song_id else '', 'total': total})
        items.append((f"plugin://script.az2music.wall/?play={song['songid']}", item, False))
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
    # A list can't be told which item to start on, and the skin's only fills as it opens (or
    # when the track changes), so once the items are in, move it to the playing track
    playing = next((i for i, s in enumerate(songs) if str(s['songid']) == song_id), 0)
    if playing:
        ready = 'Control.HasFocus(5800) + Integer.IsEqual(Container(5800).NumItems,%d)' % len(songs)
        monitor = xbmc.Monitor()
        for _ in range(30):
            if xbmc.getCondVisibility(ready):
                xbmc.executebuiltin(f'SetFocus(5800,{playing},absolute)')
                break
            if monitor.waitForAbort(0.1):
                break


def play(rpc, song_id):
    queued = rpc('Playlist.GetItems', playlistid=0).get('items') or []
    for position, entry in enumerate(queued):
        if entry.get('type') == 'song' and str(entry.get('id')) == song_id:
            rpc('Player.GoTo', playerid=0, to=position)
            return
    songs = album_songs(rpc, song_id)
    if songs:
        rpc('Playlist.Clear', playlistid=0)
        rpc('Playlist.Add', playlistid=0, item=[{'songid': s['songid']} for s in songs])
        position = next(i for i, s in enumerate(songs) if str(s['songid']) == song_id)
        rpc('Player.Open', item={'playlistid': 0, 'position': position})
