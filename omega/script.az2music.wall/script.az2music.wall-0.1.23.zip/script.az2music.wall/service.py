"""Opens Now Playing when you start music, for the skin's "Open Now Playing when music starts".

Music started from silence opens it. So does a song you pick while another plays, but a track the
playlist moves on to by itself never does, wherever you are in the skin: one Kodi queued as the
next (onQueueNextItem), one after a track ended, or one after a track with END seconds or less
left. Even then a change only counts as yours if a button was pressed in the last RECENT seconds,
as a pick is a button press. TV theme tunes and live TV are left alone.

Now Playing never starts in its Wallpaper view: when Kodi starts, and when music starts from
silence, a Wallpaper view goes back to the view it was picked from (Skin.String
NowPlaying.LastView, set by the skin's View menu: Fullscreen, or empty for Default).
"""
import time

import xbmc
import xbmcgui

END = 3.0
RECENT = 15
SILENCE = 5         # seconds without music after which music starting is "from silence"


def leave_wallpaper():
    if xbmc.getInfoLabel('Skin.String(NowPlaying.View)') == 'Wallpaper':
        last = xbmc.getInfoLabel('Skin.String(NowPlaying.LastView)')
        xbmc.executebuiltin(f'Skin.SetString(NowPlaying.View,{last})' if last else 'Skin.Reset(NowPlaying.View)')
    xbmcgui.Window(10000).clearProperty('NP_WallCentre')


def wanted():
    return xbmc.getCondVisibility(
        'Skin.HasSetting(AutoMusicVis) + Player.HasAudio + !Window.IsActive(visualisation)'
        ' + String.IsEmpty(Window(10025).Property(TvTunesIsAlive))'
        ' + ![VideoPlayer.Content(LiveTV) + !Pvr.IsPlayingRadio]')


class Player(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.file = ''          # the track being followed, and its seconds left when last looked at
        self.left = None
        self.next = False       # the playlist has moved on, or is about to, by itself
        self.stopped = 0        # when music last stopped (0: it never played)
        self.changed = 0        # when another file was first seen playing without onAVStarted

    def playing(self):
        try:
            if self.isPlayingAudio():
                return self.getPlayingFile(), max(0.0, self.getTotalTime() - self.getTime())
        except RuntimeError:    # stopped in between
            pass
        return '', None

    def yours(self):
        if not self.file and (not self.stopped or time.time() - self.stopped > SILENCE):
            return True                                         # from silence
        if self.next or (self.left is not None and self.left <= END):
            return False                                        # the playlist moving on
        return xbmc.getGlobalIdleTime() < RECENT

    def onAVStarted(self):
        file, left = self.playing()
        if not file:
            return
        if not self.file and (not self.stopped or time.time() - self.stopped > SILENCE):
            leave_wallpaper()                                   # from silence
        yours = self.yours()
        self.file, self.left, self.next, self.changed = file, left, False, 0
        if yours:
            for _ in range(20):             # a busy dialog can be closing: try for a couple of seconds
                if not wanted():
                    break
                xbmc.executebuiltin('ActivateWindow(visualisation)')
                if monitor.waitForAbort(0.1) or xbmc.getCondVisibility('Window.IsActive(visualisation)'):
                    break

    def onQueueNextItem(self):
        self.next = True

    def onPlayBackEnded(self):
        self.next = True

    def onPlayBackStopped(self):
        self.file, self.left, self.next, self.stopped = '', None, False, time.time()

    onPlayBackError = onPlayBackStopped

    def follow(self):
        """Keep the playing track's time left current; a new track is left to onAVStarted, which
        needs the last one's."""
        file, left = self.playing()
        if not file:
            if self.file and not self.next:
                self.file, self.left, self.stopped = '', None, time.time()
            return
        if file == self.file:
            self.left, self.changed = left, 0
        elif not self.changed:
            self.changed = time.time()
        elif time.time() - self.changed > 5:    # onAVStarted never came
            self.file, self.left, self.next, self.changed = file, left, False, 0


monitor = xbmc.Monitor()
leave_wallpaper()
player = Player()
while not monitor.waitForAbort(0.5):
    player.follow()
