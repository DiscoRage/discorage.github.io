"""Opens Now Playing when you start music, for the skin's "Open Now Playing when music starts".

Music started from silence opens it. So does a song you pick while another plays, but a track the
playlist moves on to by itself never does, wherever you are in the skin: one Kodi queued as the
next (onQueueNextItem), one after a track ended, or one after a track with END seconds or less
left. Even then a change only counts as yours if a button was pressed in the last RECENT seconds,
as a pick is a button press. TV theme tunes and live TV are left alone.

Now Playing never starts in its Wallpaper view: when Kodi starts, and when music starts from
silence, a Wallpaper view goes back to the view it was picked from (Skin.String
NowPlaying.LastView, set by the skin's View menu: Fullscreen, or empty for Default).

It also moves Now Playing's progress bar smoothly (Smooth).
"""
import time

import xbmc
import xbmcgui

END = 3.0
RECENT = 15
SILENCE = 5         # seconds without music after which music starting is "from silence"
GAP = 3             # seconds of nothing after the playlist moved on that mean it ended


def leave_wallpaper():
    if xbmc.getInfoLabel('Skin.String(NowPlaying.View)') == 'Wallpaper':
        last = xbmc.getInfoLabel('Skin.String(NowPlaying.LastView)')
        xbmc.executebuiltin(f'Skin.SetString(NowPlaying.View,{last})' if last else 'Skin.Reset(NowPlaying.View)')
    xbmcgui.Window(10000).clearProperty('NP_WallCentre')


def wanted():
    return xbmc.getCondVisibility(
        'Skin.HasSetting(AutoMusicVis) + Player.HasAudio + !Window.IsActive(visualisation)'
        ' + String.IsEmpty(Window(10025).Property(TvTunesIsAlive))'
        ' + ![VideoPlayer.Content(LiveTV) + !Pvr.IsPlayingRadio]')


class Player(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.file = ''          # the track being followed, and its seconds left when last looked at
        self.left = None
        self.next = False       # the playlist has moved on, or is about to, by itself
        self.stopped = 0        # when music last stopped (0: it never played)
        self.changed = 0        # when another file was first seen playing without onAVStarted
        self.idle = 0           # when nothing was first seen playing after the playlist moved on

    def playing(self):
        try:
            if self.isPlayingAudio():
                return self.getPlayingFile(), max(0.0, self.getTotalTime() - self.getTime())
        except RuntimeError:    # stopped in between
            pass
        return '', None

    def yours(self):
        if not self.file and (not self.stopped or time.time() - self.stopped > SILENCE):
            return True                                         # from silence
        if self.next or (self.left is not None and self.left <= END):
            return False                                        # the playlist moving on
        return xbmc.getGlobalIdleTime() < RECENT

    def onAVStarted(self):
        file, left = self.playing()
        if not file:
            return
        if not self.file and (not self.stopped or time.time() - self.stopped > SILENCE):
            leave_wallpaper()                                   # from silence
        yours = self.yours()
        self.file, self.left, self.next, self.changed = file, left, False, 0
        if yours:
            for _ in range(20):             # a busy dialog can be closing: try for a couple of seconds
                if not wanted():
                    break
                xbmc.executebuiltin('ActivateWindow(visualisation)')
                if monitor.waitForAbort(0.1) or xbmc.getCondVisibility('Window.IsActive(visualisation)'):
                    break

    def onQueueNextItem(self):
        self.next = True

    def onPlayBackEnded(self):
        self.next = True

    def onPlayBackStopped(self):
        self.file, self.left, self.next, self.stopped = '', None, False, time.time()

    onPlayBackError = onPlayBackStopped

    def follow(self):
        """Keep the playing track's time left current; a new track is left to onAVStarted, which
        needs the last one's."""
        file, left = self.playing()
        if not file:
            if self.file and not self.next:
                self.file, self.left, self.stopped = '', None, time.time()
            elif self.file:
                # The playlist moving on leaves a moment with nothing playing; nothing for longer
                # means it ran out, so the next start is from silence (yours), not the playlist's
                if not self.idle:
                    self.idle = time.time()
                elif time.time() - self.idle > GAP:
                    self.file, self.left, self.next, self.stopped = '', None, False, self.idle
                    self.idle = 0
            return
        self.idle = 0
        if file == self.file:
            self.left, self.changed = left, 0
        elif not self.changed:
            self.changed = time.time()
        elif time.time() - self.changed > 5:    # onAVStarted never came
            self.file, self.left, self.next, self.changed = file, left, False, 0


class Smooth:
    """Now Playing's progress bar, moving every frame instead of Kodi's whole percents.

    The skin's bar is a full-length middle and a small right end, each in a group (ids BARS, a
    pair for each place the bar is drawn). Each is given one animation: the middle grows, and
    the end slides, from where the track is now to the bar's full length in the time the track
    has left. The end is its own part so it keeps its rounded shape. Kodi draws that itself, so nothing here runs per
    frame; the animation is only given again when the track, the view or pause changes, after
    a seek (the position is more than DRIFT seconds from where the animation has it), and every
    AGAIN seconds for a bar that was hidden when it was last given. The skin shows Kodi's own
    bar until the Home property az2_np_smooth is set, and clears it when Now Playing loads.
    """
    BARS = ((2091, 2101), (2092, 2102), (2093, 2103))    # each bar's middle and right end
    DRIFT = 0.5
    AGAIN = 2.0

    def __init__(self):
        self.key = None     # track, paused, view: what the animation was given for
        self.pos = 0.0      # the track's position then, and when that was
        self.at = 0.0
        self.told = False   # a failure has been logged (once)

    def tick(self, player):
        home = xbmcgui.Window(10000)
        if not xbmc.getCondVisibility('Window.IsActive(visualisation) + Player.HasAudio'):
            self.key = None
            return
        try:
            file, total, pos = player.getPlayingFile(), player.getTotalTime(), player.getTime()
        except RuntimeError:    # stopped in between
            return
        if total <= 0:          # a stream without a length: Kodi's bar
            home.clearProperty('az2_np_smooth')
            self.key = None
            return
        still = xbmc.getCondVisibility('Player.Paused | Player.Forwarding | Player.Rewinding')
        key = (file, total, still, xbmc.getInfoLabel('Skin.String(NowPlaying.View)'),
               xbmc.getCondVisibility('Skin.HasSetting(NowPlaying.FS.FullWidth)'),
               bool(home.getProperty('az2_np_wall')))
        now = time.monotonic()
        where = self.pos if still else self.pos + now - self.at
        if (key == self.key and home.getProperty('az2_np_smooth') and abs(pos - where) <= self.DRIFT
                and (still or now - self.at < self.AGAIN)):
            return
        done = min(100.0, max(0.0, 100.0 * pos / total))
        left = 0 if still else max(1, int((total - pos) * 1000))
        to = done if still else 100.0
        found = False
        try:
            window = xbmcgui.Window(12006)
            for middle, end in self.BARS:
                bar = window.getControl(middle)
                width = bar.getWidth()
                if width <= 0:
                    raise ValueError(f'bar {middle} has no width')
                # The middle grows from its left edge (4px in from the bar's); the right end
                # slides with the middle's right edge
                bar.setAnimations([('conditional', f'effect=zoom start={done:.4f},100 end={to:.4f},100'
                                                   f' center=4,0 time={left} condition=true')])
                window.getControl(end).setAnimations([(
                    'conditional', f'effect=slide start={width * done / 100:.2f},0 end={width * to / 100:.2f},0'
                                   f' time={left} condition=true')])
                found = True
        except Exception as exc:    # the window has gone, or the skin has no such bar
            if not self.told:
                self.told = True
                xbmc.log(f'[script.az2music.wall] smooth progress: {exc!r}', xbmc.LOGWARNING)
        if found:
            self.key, self.pos, self.at = key, pos, now
            home.setProperty('az2_np_smooth', '1')
        else:
            self.key = None
            home.clearProperty('az2_np_smooth')


monitor = xbmc.Monitor()
leave_wallpaper()
player = Player()
smooth = Smooth()
while not monitor.waitForAbort(0.25):
    player.follow()
    smooth.tick(player)
