"""Opens Now Playing when you start music, for the skin's "Open Now Playing when music starts".

Every track you start opens it, including a new song picked while another plays (the skin's old
dialog only opened it when music started from nothing). A track the playlist moves on to by
itself doesn't, so browsing isn't interrupted at the end of each song: a track counts as yours
unless the one before it had run out (END seconds or less left). TV theme tunes and live TV are
left alone.
"""
import time

import xbmc

END = 3.0


def wanted():
    return xbmc.getCondVisibility(
        'Skin.HasSetting(AutoMusicVis) + Player.HasAudio + !Window.IsActive(visualisation)'
        ' + String.IsEmpty(Window(10025).Property(TvTunesIsAlive))'
        ' + ![VideoPlayer.Content(LiveTV) + !Pvr.IsPlayingRadio]')


class Player(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.file = ''          # the track being followed, and its seconds left when last looked at
        self.left = None
        self.changed = 0        # when another file was first seen playing without onAVStarted

    def playing(self):
        try:
            if self.isPlayingAudio():
                return self.getPlayingFile(), max(0.0, self.getTotalTime() - self.getTime())
        except RuntimeError:    # stopped in between
            pass
        return '', None

    def onAVStarted(self):
        file, left = self.playing()
        if not file:
            return
        yours = self.left is None or self.left > END or file == self.file
        self.file, self.left, self.changed = file, left, 0
        if yours:
            for _ in range(20):             # a busy dialog can be closing: try for a couple of seconds
                if not wanted():
                    break
                xbmc.executebuiltin('ActivateWindow(visualisation)')
                if monitor.waitForAbort(0.1) or xbmc.getCondVisibility('Window.IsActive(visualisation)'):
                    break

    def onPlayBackStopped(self):
        self.file, self.left = '', None

    onPlayBackError = onPlayBackStopped

    def onPlayBackEnded(self):
        self.left = 0                       # ran out: whatever the playlist plays next isn't yours

    def follow(self):
        """Keep the playing track's time left current; a new track is left to onAVStarted, which
        needs the last one's."""
        file, left = self.playing()
        if not file:
            return
        if file == self.file or not self.file:
            self.file, self.left, self.changed = file, left, 0
        elif not self.changed:
            self.changed = time.time()
        elif time.time() - self.changed > 5:    # onAVStarted never came
            self.file, self.left, self.changed = file, left, 0


monitor = xbmc.Monitor()
player = Player()
while not monitor.waitForAbort(0.5):
    player.follow()
