"""Now Playing for skin.az2music: the cover's colour, the blurred background and the album's tracks.

plugin://script.az2music.wall/?nowplaying=<songid>
    When the cover changes: Home properties MusicArtColor, MusicArtColorDark and MusicArtColorLight
    (a vivid colour from the cover; gold without one), and TMDb Helper's blur of the cover
    (TMDbHelper.NowPlaying.BlurImage, a prefix its own monitor leaves alone) unless the skin has
    NowPlaying.NoBlur. Lists one item with properties song (the song id, so the skin can tell an
    answer for the track it is on) and atmos (set for Atmos, read from the file as the album
    views' audio line is).
plugin://script.az2music.wall/?tracks=<songid>
    The song's album, track by track: label the title, label2 the length, properties number,
    playing (on the playing track), song and total (the album's length); then moves the skin's
    list (5800) to the playing track once it has them.
plugin://script.az2music.wall/?play=<songid>
    Jump to that track: in the playlist when it is there, otherwise play its album from it.
"""
import colorsys
import io
from collections import Counter

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

import audio

HOME = xbmcgui.Window(10000)
FALLBACK = 'FFF0C24B'


# Colour: the most vivid, common colour of the cover (as service.progressbarcolour picked it)
def hex_rgb(rgb):
    return 'FF{:02X}{:02X}{:02X}'.format(*rgb)


def adjust(colour, sat=1.0, val=1.0):
    r, g, b = (int(colour[i:i + 2], 16) / 255 for i in (2, 4, 6))
    h, s, v = colorsys.rgb_to_hsv(r, g, b)
    rgb = colorsys.hsv_to_rgb(h, max(0.18, min(0.92, s * sat)), max(0.42, min(0.92, v * val)))
    return hex_rgb(tuple(max(0, min(255, round(c * 255))) for c in rgb))


def cover_colour(cover):
    try:
        from PIL import Image
        f = xbmcvfs.File(cover)
        data = bytes(f.readBytes())
        f.close()
        img = Image.open(io.BytesIO(data))
        img.draft('RGB', (128, 128))                      # JPEG decodes small, which is most of the work
        img = img.convert('RGB')
        img.thumbnail((96, 96))
    except Exception as exc:
        xbmc.log(f'[script.az2music.wall] cover colour {cover}: {exc!r}', xbmc.LOGWARNING)
        return FALLBACK
    counts, weights = Counter(), Counter()
    pixels = list(img.getdata())
    for px in pixels:
        h, s, v = colorsys.rgb_to_hsv(*(c / 255 for c in px))
        if 0.12 <= v <= 0.95 and s >= 0.18:
            bucket = tuple(min(255, round(c / 24) * 24) for c in px)
            counts[bucket] += 1
            weights[bucket] += s * 2.3 + 1.0 - abs(v - 0.62)
    if not counts:
        mean = tuple(int(sum(px[i] for px in pixels) / len(pixels)) for i in range(3))
        return adjust(hex_rgb(mean), 1.15, 0.95)
    best = max(counts, key=lambda b: (weights[b], counts[b]))
    return adjust(hex_rgb(best), 1.10, 0.95)


def now_playing(handle, rpc, song_id):
    cover = xbmc.getInfoLabel('MusicPlayer.Cover')
    if cover and cover != HOME.getProperty('az2_np_cover'):
        colour = FALLBACK if cover.lower().startswith('default') else cover_colour(cover)
        HOME.setProperty('MusicArtColor', colour)
        HOME.setProperty('MusicArtColorDark', adjust(colour, 0.95, 0.70))
        HOME.setProperty('MusicArtColorLight', adjust(colour, 0.90, 1.12))
        HOME.setProperty('az2_np_cover', cover)
        if not xbmc.getCondVisibility('Skin.HasSetting(NowPlaying.NoBlur)'):
            xbmc.executebuiltin(f'RunScript(plugin.video.themoviedb.helper,blur_image={cover},prefix=NowPlaying)')
    item = xbmcgui.ListItem(offscreen=True)
    item.setProperty('song', song_id)
    if song_id.isdigit():
        song = rpc('AudioLibrary.GetSongDetails', songid=int(song_id),
                   properties=['file', 'bitrate', 'samplerate', 'datemodified']).get('songdetails')
        if song and 'Atmos' in audio.song_line(song):
            item.setProperty('atmos', '1')
    xbmcplugin.addDirectoryItem(handle, f'plugin://script.az2music.wall/?nowplaying={song_id}', item, False)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def length(seconds):
    return f'{seconds // 3600}:{seconds // 60 % 60:02d}:{seconds % 60:02d}' if seconds >= 3600 else f'{seconds // 60}:{seconds % 60:02d}'


def album_songs(rpc, song_id):
    song = rpc('AudioLibrary.GetSongDetails', songid=int(song_id), properties=['albumid']).get('songdetails') or {}
    if not song.get('albumid'):
        return []
    return rpc('AudioLibrary.GetSongs', filter={'albumid': song['albumid']},
               properties=['title', 'track', 'duration'], sort={'method': 'track'}).get('songs') or []


def tracks(handle, rpc, song_id):
    songs = album_songs(rpc, song_id) if song_id.isdigit() else []
    total = length(sum(s.get('duration') or 0 for s in songs))
    items = []
    for song in songs:
        item = xbmcgui.ListItem(label=song['title'], label2=length(song.get('duration') or 0), offscreen=True)
        item.setProperties({'number': f"{song.get('track', 0) % 65536:02d}", 'song': str(song['songid']),
                            'playing': '1' if str(song['songid']) == song_id else '', 'total': total})
        items.append((f"plugin://script.az2music.wall/?play={song['songid']}", item, False))
    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
    # A list can't be told which item to start on, and the skin's only fills as it opens (or
    # when the track changes), so once the items are in, move it to the playing track
    playing = next((i for i, s in enumerate(songs) if str(s['songid']) == song_id), 0)
    if playing:
        ready = 'Control.HasFocus(5800) + Integer.IsEqual(Container(5800).NumItems,%d)' % len(songs)
        monitor = xbmc.Monitor()
        for _ in range(30):
            if xbmc.getCondVisibility(ready):
                xbmc.executebuiltin(f'SetFocus(5800,{playing},absolute)')
                break
            if monitor.waitForAbort(0.1):
                break


def play(rpc, song_id):
    queued = rpc('Playlist.GetItems', playlistid=0).get('items') or []
    for position, entry in enumerate(queued):
        if entry.get('type') == 'song' and str(entry.get('id')) == song_id:
            rpc('Player.GoTo', playerid=0, to=position)
            return
    songs = album_songs(rpc, song_id)
    if songs:
        rpc('Playlist.Clear', playlistid=0)
        rpc('Playlist.Add', playlistid=0, item=[{'songid': s['songid']} for s in songs])
        position = next(i for i, s in enumerate(songs) if str(s['songid']) == song_id)
        rpc('Player.Open', item={'playlistid': 0, 'position': position})
