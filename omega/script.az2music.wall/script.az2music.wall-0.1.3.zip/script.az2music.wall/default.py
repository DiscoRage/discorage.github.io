"""Artist Wall columns for skin.az2music.

The skin's wall is one horizontal list in which every item is a column of ROWS artists, so the
whole wall pans together under a fixed highlight. Artists fill each column top to bottom, then
the next column, so the wall reads alphabetically from left to right.

Called by the skin as
plugin://script.az2music.wall/?rows=5&cols=7&rest=2&row0=7310&path=<music library folder>
(path last and unparsed, since library paths can carry their own query string). cols is how many
columns fit on screen, rest the screen column the highlight rests on while the wall pans, and
row0 the id of the skin's first row button.

Each column item has properties name<r>, thumb<r>, fanart<r>, genre<r>, path<r> and letter<r>
(the artist's place in the letter bar: 0 for #, 1-26 for A-Z) for rows r = 0..ROWS-1, plus
index (0-based column) and count (artists in the column).

For the letter bar it also sets Home window properties az2_wall_jump_<n>_col, _shift and _focus
for n = 0..26: the column to select, the highlight's screen column and the row button to focus
to land on that letter's first artist (or the next letter's, if it has none).

An empty path (the skin passes one when the wall isn't showing) lists nothing.
"""
import json
import math
import re
import string
import sys
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

ADDON = 'script.az2music.wall'
LETTERS = '#' + string.ascii_uppercase


def rpc(method, **params):
    result = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    if 'error' in result:
        xbmc.log(f'[{ADDON}] {method}: {result["error"]}', xbmc.LOGWARNING)
        return {}
    return result.get('result', {})


def unwrap(url):
    """JSON-RPC wraps art as image://<quoted url>/. Hand the skin the plain URL: the background's
    multiimage reads the wrapped form as a folder and can't open it."""
    if url.startswith('image://'):
        return urllib.parse.unquote(url[len('image://'):].rstrip('/'))
    return url


def letter(name, ignore_the):
    """Place in the letter bar, filed as Kodi sorts: "The X" under X when articles are ignored."""
    if ignore_the and name[:4].lower() == 'the ':
        name = name[4:]
    first = name[:1].upper()
    return LETTERS.index(first) if first in LETTERS[1:] else 0


def artists(path):
    ignore_the = rpc('Settings.GetSettingValue', setting='filelists.ignorethewhensorting').get('value', True)
    items = rpc('Files.GetDirectory', directory=path, media='music', properties=['art', 'genre'],
                sort={'method': 'label', 'order': 'ascending', 'ignorearticle': bool(ignore_the)}).get('files') or []
    for item in items:
        if item.get('filetype') != 'directory' or re.search(r'/-1/', item.get('file', '')):
            continue
        art = item.get('art') or {}
        name = item.get('label', '')
        yield {'name': name, 'thumb': unwrap(art.get('thumb', '')), 'fanart': unwrap(art.get('fanart', '')),
               'genre': ' • '.join(item.get('genre') or []),
               'path': item.get('file', ''), 'letter': str(letter(name, ignore_the))}


def set_jumps(found, rows, cols, rest, row0):
    """Where each letter starts. The highlight rests on screen column rest where it can, as it
    does while the wall pans, and goes nearer the edge only at the start and end of the wall."""
    home = xbmcgui.Window(10000)
    columns = math.ceil(len(found) / rows)
    firsts = {}
    for i, artist in enumerate(found):
        firsts.setdefault(int(artist['letter']), i)
    target = len(found) - 1
    for n in reversed(range(len(LETTERS))):
        target = firsts.get(n, target)          # a letter with no artists jumps to the next that has
        c, r = divmod(max(target, 0), rows)
        col = max(0, min(c - rest, columns - cols))
        home.setProperty(f'az2_wall_jump_{n}_col', str(col))
        home.setProperty(f'az2_wall_jump_{n}_shift', str(c - col))
        home.setProperty(f'az2_wall_jump_{n}_focus', str(row0 + r))


def main():
    handle = int(sys.argv[1])
    query, _, path = sys.argv[2].lstrip('?').partition('path=')
    args = dict(urllib.parse.parse_qsl(query))
    rows = max(1, int(args.get('rows', 5)))
    found = list(artists(path)) if path else []
    if found:
        set_jumps(found, rows, int(args.get('cols', 7)), int(args.get('rest', 2)), int(args.get('row0', 7310)))

    columns = []
    for c in range(math.ceil(len(found) / rows)):
        cells = found[c * rows:(c + 1) * rows]
        props = {'index': str(c), 'count': str(len(cells))}
        for r, artist in enumerate(cells):
            props.update({f'{key}{r}': value for key, value in artist.items()})
        item = xbmcgui.ListItem(label=cells[0]['name'], offscreen=True)
        item.setProperties(props)
        columns.append((f'plugin://{ADDON}/?column={c}', item, False))

    xbmcplugin.addDirectoryItems(handle, columns, len(columns))
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


main()
