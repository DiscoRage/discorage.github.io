"""Kodi's music library, through JSON-RPC only: nothing here touches the database file."""
import json
import urllib.parse

import xbmc

ADDON = 'script.az2music.scraper'


def log(message, level=xbmc.LOGINFO):
    xbmc.log(f'[{ADDON}] {message}', level)


def rpc(method, **params):
    result = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    if 'error' in result:
        log(f'{method} {params}: {result["error"]}', xbmc.LOGWARNING)
        return None
    return result.get('result')


def unwrap(url):
    """Art comes back as image://<quoted url>/; the plain URL or path is what can be opened."""
    if url.startswith('image://'):
        return urllib.parse.unquote(url[len('image://'):].rstrip('/'))
    return url


def albums():
    result = rpc('AudioLibrary.GetAlbums', includesingles=True, properties=[
        'title', 'displayartist', 'year', 'genre', 'art', 'musicbrainzreleasegroupid', 'musicbrainzalbumid',
        'description', 'mood', 'style', 'theme', 'releasetype']) or {}
    return result.get('albums') or []


def track_counts():
    counts = {}
    for song in (rpc('AudioLibrary.GetSongs', properties=['albumid']) or {}).get('songs') or []:
        counts[song['albumid']] = counts.get(song['albumid'], 0) + 1
    return counts


def album_artists():
    """Only artists credited on albums: featured artists on a song are left alone."""
    result = rpc('AudioLibrary.GetArtists', albumartistsonly=True, properties=[
        'genre', 'art', 'musicbrainzartistid', 'description', 'mood', 'style', 'instrument']) or {}
    return result.get('artists') or []


def all_artists():
    result = rpc('AudioLibrary.GetArtists', albumartistsonly=False, properties=[
        'description', 'mood', 'style', 'instrument']) or {}
    return result.get('artists') or []


def set_album(albumid, **fields):
    return rpc('AudioLibrary.SetAlbumDetails', albumid=albumid, **fields) is not None


def set_artist(artistid, **fields):
    return rpc('AudioLibrary.SetArtistDetails', artistid=artistid, **fields) is not None


def setting(name):
    return (rpc('Settings.GetSettingValue', setting=name) or {}).get('value')


def set_setting(name, value):
    return rpc('Settings.SetSettingValue', setting=name, value=value) is not None
