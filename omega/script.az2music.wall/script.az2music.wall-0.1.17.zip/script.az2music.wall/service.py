"""Now Playing's background work: opening it when you start music, and its smooth progress bar.

Opening it, for the skin's "Open Now Playing when music starts":

Music started from silence opens it. So does a song you pick while another plays, but a track the
playlist moves on to by itself never does, wherever you are in the skin: one Kodi queued as the
next (onQueueNextItem), one after a track ended, or one after a track with END seconds or less
left. Even then a change only counts as yours if a button was pressed in the last RECENT seconds,
as a pick is a button press. TV theme tunes and live TV are left alone.

The smooth bar (Motion: Smooth): while Now Playing is open, every TICK seconds, in pixels of each
bar width the skin has (WIDTHS), where the track will be by the next update (the head, which
glides there) and where it was at the last (the body, behind it), as the Home properties
tools/make_np_progress.py describes.
"""
import time

import xbmc
import xbmcgui

END = 3.0
RECENT = 15
SILENCE = 5         # seconds without music after which music starting is "from silence"
TICK = 0.2
WIDTHS, BITS, BLOCK, RADIUS = (600, 680, 1632), 11, 32, 4
HOME = xbmcgui.Window(10000)


def wanted():
    return xbmc.getCondVisibility(
        'Skin.HasSetting(AutoMusicVis) + Player.HasAudio + !Window.IsActive(visualisation)'
        ' + String.IsEmpty(Window(10025).Property(TvTunesIsAlive))'
        ' + ![VideoPlayer.Content(LiveTV) + !Pvr.IsPlayingRadio]')


class Player(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.file = ''          # the track being followed, and its seconds left when last looked at
        self.left = None
        self.next = False       # the playlist has moved on, or is about to, by itself
        self.stopped = 0        # when music last stopped (0: it never played)
        self.changed = 0        # when another file was first seen playing without onAVStarted

    def playing(self):
        try:
            if self.isPlayingAudio():
                return self.getPlayingFile(), max(0.0, self.getTotalTime() - self.getTime())
        except RuntimeError:    # stopped in between
            pass
        return '', None

    def yours(self):
        if not self.file and (not self.stopped or time.time() - self.stopped > SILENCE):
            return True                                         # from silence
        if self.next or (self.left is not None and self.left <= END):
            return False                                        # the playlist moving on
        return xbmc.getGlobalIdleTime() < RECENT

    def onAVStarted(self):
        file, left = self.playing()
        if not file:
            return
        yours = self.yours()
        self.file, self.left, self.next, self.changed = file, left, False, 0
        if yours:
            for _ in range(20):             # a busy dialog can be closing: try for a couple of seconds
                if not wanted():
                    break
                xbmc.executebuiltin('ActivateWindow(visualisation)')
                if monitor.waitForAbort(0.1) or xbmc.getCondVisibility('Window.IsActive(visualisation)'):
                    break

    def onQueueNextItem(self):
        self.next = True

    def onPlayBackEnded(self):
        self.next = True

    def onPlayBackStopped(self):
        self.file, self.left, self.next, self.stopped = '', None, False, time.time()

    onPlayBackError = onPlayBackStopped

    def follow(self):
        """Keep the playing track's time left current; a new track is left to onAVStarted, which
        needs the last one's."""
        file, left = self.playing()
        if not file:
            if self.file and not self.next:
                self.file, self.left, self.stopped = '', None, time.time()
            return
        if file == self.file:
            self.left, self.changed = left, 0
        elif not self.changed:
            self.changed = time.time()
        elif time.time() - self.changed > 5:    # onAVStarted never came
            self.file, self.left, self.next, self.changed = file, left, False, 0


class Bar:
    def __init__(self):
        self.set = {}           # the properties as last set
        self.head = {}          # each width's head, as last sent

    def put(self, name, value):
        if self.set.get(name) != value:
            HOME.setProperty(name, value)
            self.set[name] = value

    def update(self):
        try:
            total = player.getTotalTime()
            at = player.getTime() + (0 if xbmc.getCondVisibility('Player.Paused') else TICK)
        except RuntimeError:
            return
        share = max(0.0, min(1.0, at / total)) if total > 0 else 0.0
        for width in WIDTHS:
            head = round(share * width)
            # The body ends where the head's glide starts, less the head's own rounded end
            body = max(0, min(self.head.get(width, head), head) - RADIUS)
            self.head[width] = head
            name = f'az2_np_{width}'
            for k in range(BITS):
                self.put(f'{name}_h{k}', '1' if head >> k & 1 else '')
                self.put(f'{name}_b{k}', '1' if body >> k & 1 else '')
            self.put(name, str(body))
            self.put(f'{name}_px', str(body % BLOCK))
            self.put(f'{name}_c', str(body // BLOCK))
            self.put(f'{name}_start', '1' if head > 0 else '')
            self.put(f'{name}_on', '1' if head > 2 * RADIUS else '')


monitor = xbmc.Monitor()
player = Player()
bar = Bar()
last = 0
while True:
    smooth = xbmc.getCondVisibility('Window.IsActive(visualisation) + Player.HasAudio'
                                    ' + !Skin.HasSetting(NowPlaying.StockProgress)')
    if smooth:
        bar.update()
    if time.time() - last >= 0.5:
        player.follow()
        last = time.time()
    if monitor.waitForAbort(TICK if smooth else 0.5):
        break
