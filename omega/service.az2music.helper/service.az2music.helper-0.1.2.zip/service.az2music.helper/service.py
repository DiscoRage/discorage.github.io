"""Background helper for Arctic Zephyr 2: Music Edition.

Opens Now Playing when the user starts music, but not when an album simply moves on
to its next track. The difference is how the previous track ended: an automatic
change only happens when the previous song has (almost) run out, while picking a
song cuts the current one off with time left, or starts from silence.
"""
import xbmc

ADDON_ID = 'service.az2music.helper'
POLL = 0.5          # seconds between position checks
NATURAL_END = 4.0   # a previous track with less than this left ended by itself


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'[{ADDON_ID}] {msg}', level)


class Monitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.player = xbmc.Player()
        self.remaining = None  # seconds left in the current audio track, None when nothing plays

    def poll(self):
        """Remember how much of the current audio track is left."""
        try:
            if self.player.isPlayingAudio():
                self.remaining = self.player.getTotalTime() - self.player.getTime()
            elif not xbmc.getCondVisibility('Player.HasMedia'):
                self.remaining = None
        except RuntimeError:  # player changed between the check and the call
            pass

    def onNotification(self, sender, method, data):
        if method == 'Player.OnAVStart':
            self.on_start()

    def on_start(self):
        if not xbmc.getCondVisibility('Player.HasAudio + !Player.HasVideo'):
            return
        previous = self.remaining
        self.remaining = None
        if previous is not None and previous < NATURAL_END:
            log(f'next track after natural end ({previous:.1f}s left), staying put', xbmc.LOGDEBUG)
            return
        if xbmc.getCondVisibility('Window.IsActive(visualisation)'):
            return
        # Skin Settings: "Open Now Playing when music starts"
        if not xbmc.getCondVisibility('Skin.HasSetting(AutoMusicVis)'):
            return
        reason = 'started from silence' if previous is None else f'interrupted with {previous:.1f}s left'
        log(f'music {reason}, opening Now Playing')
        xbmc.executebuiltin('ActivateWindow(visualisation)')


if __name__ == '__main__':
    monitor = Monitor()
    log('started')
    while not monitor.waitForAbort(POLL):
        monitor.poll()
