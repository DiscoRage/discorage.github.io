"""Background helper for Arctic Zephyr 2: Music Edition.

Opens Now Playing when the user starts music. When you play something, Kodi clears
the music playlist and then starts playback; when an album simply moves on to its
next track there is no clear. So "music playlist cleared, then audio starts" means
the user pressed play, and only then do we switch screens.
"""
import json
import time

import xbmc

ADDON_ID = 'service.az2music.helper'
MUSIC_PLAYLIST = 0
CLEAR_WINDOW = 10  # seconds between the playlist clear and playback starting


def log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f'[{ADDON_ID}] {msg}', level)


class Monitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.cleared_at = 0.0

    def onNotification(self, sender, method, data):
        if method == 'Playlist.OnClear':
            try:
                playlist = json.loads(data).get('playlistid')
            except (ValueError, AttributeError):
                playlist = None
            if playlist == MUSIC_PLAYLIST:
                self.cleared_at = time.monotonic()
        elif method in ('Player.OnPlay', 'Player.OnAVStart'):
            self.open_now_playing()

    def open_now_playing(self):
        if not self.cleared_at or time.monotonic() - self.cleared_at > CLEAR_WINDOW:
            return
        # OnPlay can arrive before the player reports audio; OnAVStart will retry.
        if not xbmc.getCondVisibility('Player.HasAudio + !Player.HasVideo'):
            return
        self.cleared_at = 0.0
        if not xbmc.getCondVisibility('Window.IsActive(visualisation)'):
            log('music started by user, opening Now Playing')
            xbmc.executebuiltin('ActivateWindow(visualisation)')


if __name__ == '__main__':
    monitor = Monitor()
    log('started', xbmc.LOGINFO)
    monitor.waitForAbort()
