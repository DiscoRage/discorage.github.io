"""Minimalist Scraper: year, genre and the largest artwork for the music library, nothing else.

Opened from Programs (or a menu item running RunScript(script.az2music.scraper)). See scrape.py for
scraping and clean.py for the one-time clean.
"""
import xbmcaddon
import xbmcgui

import clean
import scrape


def main():
    dialog = xbmcgui.Dialog()
    if scrape.running():
        if dialog.yesno('Minimalist Scraper', f'{scrape.running()} is in progress. Stop it?'):
            scrape.stop()
        return
    waiting = len(scrape.load()['unmatched'])
    menu = [('Scrape new albums', lambda: scrape.run_albums(False)),
            ('Scrape all albums again', lambda: scrape.run_albums(True)),
            ('Scrape album artists', scrape.run_artists)]
    if waiting:
        menu.append((f'Albums not found ({waiting})', scrape.review))
    menu += [('Clean library (one time)', clean.run),
             ('Settings', xbmcaddon.Addon().openSettings)]
    pick = dialog.select('Minimalist Scraper', [label for label, _ in menu])
    if pick >= 0:
        menu[pick][1]()


main()
