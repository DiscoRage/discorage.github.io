"""Where year, genre and artwork come from, and how big each image is.

An album is found on TheAudioDB or, failing that (older and indie records, mostly), MusicBrainz:
they give its year and genre (MusicBrainz the year only). Covers come from those two (TheAudioDB
700px, MusicBrainz through the Cover Art Archive, any size), fanart.tv (usually 1000px; needs an
API key and the album's release group, which both give) and Apple Music, for artwork only
(originals, often 1500-4000px). MusicBrainz IDs are only used to look things up, never stored.
Artist images: TheAudioDB and fanart.tv.

A candidate is an album or artist that matches the library's exactly once names are normalised
(case, accents, punctuation, a leading "The", "&"/"and") and, for albums, edition words in
brackets are dropped ("(Atmos Mix)", "(Deluxe Edition)"...). Apple singles and EPs never match,
nor does an album with far fewer tracks than the library's. Searching again by hand loosens all
that and lists whatever the search finds.
"""
import io
import json
import re
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request

import xbmcvfs

from library import log, unwrap

AGENT = 'MinimalistScraper/0.1 ( https://github.com/DiscoRage/Arctic-Zephyr-2-Music-Edition )'
TADB = 'https://www.theaudiodb.com/api/v1/json/123'     # TheAudioDB's free key
ITUNES = 'https://itunes.apple.com/search'
FANART = 'https://webservice.fanart.tv/v3/music'
MUSICBRAINZ = 'https://musicbrainz.org/ws/2/release-group/'
COVERART = 'https://coverartarchive.org/release-group/{}/front'
PAUSE = {'itunes.apple.com': 3.2, 'www.theaudiodb.com': 2.1, 'musicbrainz.org': 1.1}  # their rate limits
_last = {}


def get_json(url, params=None):
    """A source's JSON, keeping to its rate limit; a "slow down" (503 or 429) is retried after a
    growing wait, three times."""
    if params:
        url += '?' + urllib.parse.urlencode(params)
    host = urllib.parse.urlsplit(url).netloc
    for attempt in range(4):
        wait = _last.get(host, 0) + PAUSE.get(host, 0) - time.time()
        if wait > 0:
            time.sleep(wait)
        _last[host] = time.time()
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': AGENT}), timeout=20) as response:
                return json.loads(response.read().decode('utf-8', 'replace') or 'null')
        except urllib.error.HTTPError as exc:
            if exc.code in (429, 503) and attempt < 3:
                time.sleep(2 * (attempt + 1))
                continue
            log(f'{host}: {exc}')
        except (urllib.error.URLError, OSError, ValueError) as exc:
            log(f'{host}: {exc}')
        return None


# Matching
def norm(text):
    text = unicodedata.normalize('NFKD', text or '').encode('ascii', 'ignore').decode().lower()
    text = re.sub(r'\s*&\s*', ' and ', text)
    text = re.sub(r'[^a-z0-9]+', ' ', text).strip()
    return re.sub(r'^the ', '', text)


def base_title(title):
    """The title without edition words: trailing (...) / [...] and Apple's " - Single", " - EP"."""
    title = re.sub(r'\s+-\s+(single|ep)$', '', title or '', flags=re.I)
    while True:
        stripped = re.sub(r'\s*[(\[][^()\[\]]*[)\]]\s*$', '', title)
        if stripped == title or not stripped:
            return norm(title)
        title = stripped


def plain_title(title):
    """The title as written, without trailing edition words in brackets: what to search for."""
    while True:
        stripped = re.sub(r'\s*[(\[][^()\[\]]*[)\]]\s*$', '', title or '')
        if stripped == title or not stripped:
            return title
        title = stripped


def same_artist(a, b):
    return norm(a) == norm(b)


# Image sizes
def read(path, start, length):
    f = xbmcvfs.File(path)
    try:
        if start:
            f.seek(start, 0)
        return bytes(f.readBytes(length))
    finally:
        f.close()


def embedded_image(path):
    """The start of the picture embedded in a music file (Kodi's music@<file>): FLAC and MP3 keep it
    near the beginning, DSF in the ID3 tag its header points to at the end."""
    head = read(path, 0, 4194304)
    if head[:4] == b'DSD ':
        tag = int.from_bytes(head[20:28], 'little')
        head = read(path, tag, 4194304) if tag else b''
    starts = [i for i in (head.find(b'\xff\xd8\xff'), head.find(b'\x89PNG')) if i >= 0]
    return head[min(starts):] if starts else b''


def image_size(url):
    """(width, height) of an image, local, network, web or embedded in a music file, read from its
    first part; (0, 0) if unknown."""
    if not url:
        return (0, 0)
    url = unwrap(url)
    try:
        if url.startswith('music@'):
            data = embedded_image(url[len('music@'):])
        elif url.startswith(('http://', 'https://')):
            request = urllib.request.Request(url, headers={'User-Agent': AGENT, 'Range': 'bytes=0-524287'})
            with urllib.request.urlopen(request, timeout=20) as response:
                data = response.read(524288)
        else:
            f = xbmcvfs.File(url)
            data = bytes(f.readBytes(524288))
            f.close()
        from PIL import Image
        return Image.open(io.BytesIO(data)).size
    except Exception as exc:
        log(f'size of {url}: {exc!r}')
        return (0, 0)


def square(size):
    w, h = size
    return w and h and abs(w - h) <= 0.03 * max(w, h)


# Albums
def tadb_albums(artist, title):
    data = get_json(f'{TADB}/searchalbum.php', {'s': artist, 'a': title}) or {}
    found = []
    for item in data.get('album') or []:
        found.append({
            'source': 'TheAudioDB', 'artist': item.get('strArtist') or '', 'title': item.get('strAlbum') or '',
            'year': (item.get('intYearReleased') or '')[:4], 'genre': item.get('strGenre') or '',
            'covers': [item[k] for k in ('strAlbumThumbHQ', 'strAlbumThumb') if item.get(k)],
            'releasegroup': item.get('strMusicBrainzID') or '', 'tracks': 0})
    return found


def apple_albums(term, limit=25):
    data = get_json(ITUNES, {'term': term, 'entity': 'album', 'media': 'music', 'limit': limit}) or {}
    found = []
    for item in data.get('results') or []:
        art = item.get('artworkUrl100') or ''
        found.append({
            'source': 'Apple Music', 'artist': item.get('artistName') or '', 'title': item.get('collectionName') or '',
            'year': '', 'genre': '',                        # artwork only
            'covers': [art.replace('100x100bb', '10000x10000bb')] if art else [],
            'releasegroup': '', 'tracks': item.get('trackCount') or 0})
    return found


def musicbrainz_albums(artist, title, limit=5):
    query = 'releasegroup:"{}"'.format(title.replace('"', ''))
    if artist:
        query += ' AND artist:"{}"'.format(artist.replace('"', ''))
    data = get_json(MUSICBRAINZ, {'query': query, 'fmt': 'json', 'limit': limit}) or {}
    found = []
    for group in data.get('release-groups') or []:
        credit = (group.get('artist-credit') or [{}])[0]
        found.append({
            'source': 'MusicBrainz', 'artist': credit.get('name') or (credit.get('artist') or {}).get('name') or '',
            'title': group.get('title') or '', 'year': (group.get('first-release-date') or '')[:4], 'genre': '',
            'covers': [COVERART.format(group['id'])], 'releasegroup': group['id'], 'tracks': 0,
            'type': group.get('primary-type') or ''})
    return found


def fanart_album_covers(releasegroup, key):
    if not (releasegroup and key):
        return []
    data = get_json(f'{FANART}/albums/{releasegroup}', {'api_key': key}) or {}
    covers = []
    for album in (data.get('albums') or {}).values():
        covers += [c['url'] for c in sorted(album.get('albumcover') or [], key=lambda c: -int(c.get('likes') or 0)) if c.get('url')]
    return covers


def apple_covers(artist, title, tracks):
    """Apple's matches for an album, for their covers. Apple lists every edition: when it has this
    one (same title, closest track count) the others are left out, as a deluxe reissue's art is
    often different; singles and EPs, and albums with far fewer tracks, never match."""
    want = base_title(title)
    found = []
    for c in apple_albums(f'{artist} {plain_title(title)}'):
        if not same_artist(c['artist'], artist) or base_title(c['title']) != want:
            continue
        if re.search(r'\s-\s(single|ep)$', c['title'], re.I) or (tracks and c['tracks'] and c['tracks'] < 0.6 * tracks):
            continue
        found.append(c)
    exact = [c for c in found if norm(c['title']) == norm(plain_title(title))]
    if exact:
        found = [min(exact, key=lambda c: abs(c['tracks'] - tracks) if tracks else 0)]
    return found


def fanart_candidates(found, artist, title, key):
    candidates = []
    for group in {c['releasegroup'] for c in found if c['releasegroup']}:
        covers = fanart_album_covers(group, key)
        if covers:
            candidates.append({'source': 'fanart.tv', 'artist': artist, 'title': title, 'year': '', 'genre': '',
                               'covers': covers[:3], 'releasegroup': group, 'tracks': 0})
    return candidates


def album_candidates(artist, title, tracks, key):
    """An album's matches: TheAudioDB's or else MusicBrainz's (empty when neither knows it), with
    Apple's and fanart.tv's added for their covers."""
    want = base_title(title)
    found = [c for c in tadb_albums(artist, plain_title(title))
             if same_artist(c['artist'], artist) and base_title(c['title']) == want]
    if not found:
        found = [c for c in musicbrainz_albums(artist, plain_title(title))
                 if same_artist(c['artist'], artist) and base_title(c['title']) == want and c['type'] != 'Single']
    if not found:
        return []
    return found + apple_covers(artist, title, tracks) + fanart_candidates(found, artist, title, key)


def search_albums(artist, title):
    """For a search by hand: whatever TheAudioDB and MusicBrainz find, singles and EPs included."""
    found = tadb_albums(artist, title) if artist and title else []
    return found + (musicbrainz_albums(artist, title, limit=10) if title else [])


def largest(urls, need_square=True):
    """(url, size) of the largest image among urls (square ones only for covers and artist
    thumbs), or ('', (0, 0))."""
    best = ('', (0, 0))
    for url in dict.fromkeys(urls):
        size = image_size(url)
        if (square(size) or not need_square) and size[0] * size[1] > best[1][0] * best[1][1]:
            best = (url, size)
    return best


# Artists
def tadb_artist(name):
    data = get_json(f'{TADB}/search.php', {'s': name}) or {}
    for item in data.get('artists') or []:
        if same_artist(item.get('strArtist'), name):
            return {'genre': item.get('strGenre') or '', 'mbid': item.get('strMusicBrainzID') or '',
                    'thumb': [item[k] for k in ('strArtistThumb',) if item.get(k)],
                    'fanart': [item[k] for k in ('strArtistFanart', 'strArtistFanart2', 'strArtistFanart3') if item.get(k)]}
    return None


def fanart_artist(mbid, key):
    if not (mbid and key):
        return {'thumb': [], 'fanart': []}
    data = get_json(f'{FANART}/{mbid}', {'api_key': key}) or {}
    pick = lambda k: [i['url'] for i in sorted(data.get(k) or [], key=lambda i: -int(i.get('likes') or 0)) if i.get('url')][:4]
    return {'thumb': pick('artistthumb'), 'fanart': pick('artistbackground')}
