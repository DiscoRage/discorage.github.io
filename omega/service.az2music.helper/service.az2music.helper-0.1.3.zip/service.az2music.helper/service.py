"""Background helper for Arctic Zephyr 2: Music Edition.

Opens Now Playing when the user starts music, but not when an album simply moves on
to its next track. The difference is how the previous track ended: an automatic
change only happens when the previous song has (almost) run out, while picking a
song cuts the current one off with time left, or starts from silence.

Track changes are detected by polling the playing file rather than waiting for
Player.OnAVStart, which Kodi's music player (PAPlayer) doesn't reliably send.
"""
import xbmc

ADDON_ID = 'service.az2music.helper'
POLL = 0.5          # seconds between checks
NATURAL_END = 4.0   # a previous track with less than this left ended by itself


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'[{ADDON_ID}] {msg}', level)


class Watcher:
    def __init__(self):
        self.player = xbmc.Player()
        self.file = None       # audio file currently playing
        self.remaining = None  # seconds left in it at the last check

    def poll(self):
        try:
            playing = self.player.isPlayingAudio() and not xbmc.getCondVisibility('Player.HasVideo')
            current = self.player.getPlayingFile() if playing else None
            if playing and current and current != self.file:
                self.on_new_track(current)
            if playing:
                self.remaining = self.player.getTotalTime() - self.player.getTime()
            elif not xbmc.getCondVisibility('Player.HasMedia'):
                self.file, self.remaining = None, None
        except RuntimeError:  # player changed between the check and the call
            pass

    def on_new_track(self, current):
        previous = self.remaining if self.file else None
        self.file, self.remaining = current, None
        if previous is not None and previous < NATURAL_END:
            log(f'next track after natural end ({previous:.1f}s left), staying put', xbmc.LOGDEBUG)
            return
        reason = 'started from silence' if previous is None else f'interrupted with {previous:.1f}s left'
        if not xbmc.getCondVisibility('Skin.HasSetting(AutoMusicVis)'):
            log(f'music {reason}; "Open Now Playing when music starts" is off')
            return
        if xbmc.getCondVisibility('Window.IsActive(visualisation)'):
            return
        log(f'music {reason}, opening Now Playing')
        xbmc.executebuiltin('ActivateWindow(visualisation)')


if __name__ == '__main__':
    monitor = xbmc.Monitor()
    watcher = Watcher()
    log('started')
    while not monitor.waitForAbort(POLL):
        watcher.poll()
