# First-run Kodi settings the skin relies on (run once from Startup.xml, before SkinInit is set).
# Run with RunScript(special://skin/extras/scripts/kodi_defaults.py)
import json

import xbmc

SETTINGS = {
    # Sort "The B-52's" under B: Settings > Media > General > Ignore articles when sorting
    'filelists.ignorethewhensorting': True,
}

for setting, value in SETTINGS.items():
    result = xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.SetSettingValue',
        'params': {'setting': setting, 'value': value}}))
    if '"error"' in result:
        xbmc.log(f'[skin.az2music] kodi_defaults: could not set {setting}: {result}', xbmc.LOGWARNING)
