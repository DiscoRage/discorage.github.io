"""Minimalist Album Scraper: Kodi runs this for each album it scrapes (see kodi_scraper.py)."""
import kodi_scraper

kodi_scraper.run('albums')
