# Arctic Zephyr 2: Music Edition

A music-first Arctic Zephyr 2 for Kodi 21. Install it from the DiscoRage repository:
https://github.com/DiscoRage/discorage.github.io (the repository add-on is linked from https://discorage.github.io).

Based on Arctic Zephyr 2: Resurrection by DenDyGH and heppen, which builds on Arctic Zephyr 2
by jurialmunkey as ported to Kodi 19 by pkscout.

Licence: Creative Commons BY-NC-SA 4.0 (see LICENSE.txt).

Recommended Kodi setting: Settings > Media > General > "Ignore articles when sorting" on, so
"The B-52's" files under B. The skin no longer turns this on for you.
