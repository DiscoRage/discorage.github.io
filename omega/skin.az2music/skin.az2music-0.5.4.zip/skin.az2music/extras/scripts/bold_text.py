# Skin Settings "Bold text" toggle: switches between the D Laboratories fontsets.
# Run with RunScript(special://skin/extras/scripts/bold_text.py)
import json

import xbmc

REGULAR = 'D Laboratories'
BOLD = 'D Laboratories Bold'

target = REGULAR if xbmc.getInfoLabel('Skin.Font') == BOLD else BOLD
result = xbmc.executeJSONRPC(json.dumps({
    'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.SetSettingValue',
    'params': {'setting': 'lookandfeel.font', 'value': target}}))
if '"error"' in result:
    xbmc.log(f'[skin.az2music] bold_text: could not set font to {target}: {result}', xbmc.LOGWARNING)
